#!/usr/bin/env python3
"""Reproduce the shared-memory and single-host multi-process scaling study.

The process backend uses fork when available and spawn otherwise. On
spawn-based platforms, worker initialization copies the read-only arrays once;
pool initialization is excluded from the iterative timing. Per-iteration task
dispatch and collection are included.
"""
from __future__ import annotations

import argparse
import json
import multiprocessing as mp
import os
import platform
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

# Prevent nested BLAS parallelism before importing NumPy.
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")
os.environ.setdefault("NUMEXPR_NUM_THREADS", "1")

import numpy as np
import pandas as pd

_GB: np.ndarray | None = None
_GC: np.ndarray | None = None
_GTAU: np.ndarray | None = None


def _initialize_process_worker(
    b: np.ndarray, c: np.ndarray, tau: np.ndarray
) -> None:
    global _GB, _GC, _GTAU
    _GB, _GC, _GTAU = b, c, tau


def _process_predict(args: tuple[int, np.ndarray, np.ndarray]) -> np.ndarray:
    i, xi, lam = args
    if _GB is None or _GC is None or _GTAU is None:
        raise RuntimeError("Process worker arrays were not initialized.")
    b = _GB[i]
    c = _GC[i]
    tau = float(_GTAU[i])
    grad = b.T @ (b @ xi - c)
    return xi - (grad - lam) / tau


def _thread_predict(
    args: tuple[int, np.ndarray, np.ndarray],
    b: np.ndarray,
    c: np.ndarray,
    tau: np.ndarray,
) -> np.ndarray:
    i, xi, lam = args
    bi = b[i]
    grad = bi.T @ (bi @ xi - c[i])
    return xi - (grad - lam) / tau[i]


def generate_problem(
    p: int = 16,
    ell: int = 1200,
    n: int = 500,
    seed: int = 20260727,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Generate the deterministic dense exchange problem used in the paper."""
    rng = np.random.default_rng(seed)
    b = rng.standard_normal((p, ell, n)) / np.sqrt(ell)
    x_star = rng.standard_normal((p, n))
    x_star[-1] = -np.sum(x_star[:-1], axis=0)
    c = np.einsum("pen,pn->pe", b, x_star, optimize=True)

    tau = np.empty(p)
    alpha = 1.5
    for i in range(p):
        bi = b[i]
        gram = bi.T @ bi
        # Compute the largest eigenvalue directly; the 10% margin is applied
        # when choosing tau below.
        lip = float(np.linalg.eigvalsh(gram)[-1])
        tau[i] = 1.10 * lip / (2.0 - alpha) + 1e-12
    return b, c, tau


def merit(
    b: np.ndarray, c: np.ndarray, x: np.ndarray
) -> tuple[float, float, float]:
    residual = np.einsum("pen,pn->pe", b, x, optimize=True) - c
    objective = 0.5 * float(np.sum(residual * residual))
    feasibility = float(np.linalg.norm(np.sum(x, axis=0)))
    return max(objective, feasibility), objective, feasibility


def one_run(
    b: np.ndarray,
    c: np.ndarray,
    tau: np.ndarray,
    workers: int,
    backend: str,
    iterations: int = 200,
    alpha: float = 1.5,
    beta: float = 1.0,
) -> dict[str, object]:
    p, _, n = b.shape
    x = np.zeros((p, n))
    lam = np.zeros(n)
    setup = 0.0

    if backend == "threads":
        t_setup = time.perf_counter()
        executor = ThreadPoolExecutor(max_workers=workers)
        setup = time.perf_counter() - t_setup

        def predict(x_current: np.ndarray, lam_current: np.ndarray) -> np.ndarray:
            args = [(i, x_current[i].copy(), lam_current.copy()) for i in range(p)]
            return np.vstack(
                list(executor.map(lambda a: _thread_predict(a, b, c, tau), args))
            )

    elif backend == "processes":
        start_method = "fork" if "fork" in mp.get_all_start_methods() else "spawn"
        context = mp.get_context(start_method)
        t_setup = time.perf_counter()
        pool = context.Pool(
            processes=workers,
            initializer=_initialize_process_worker,
            initargs=(b, c, tau),
        )
        setup = time.perf_counter() - t_setup

        def predict(x_current: np.ndarray, lam_current: np.ndarray) -> np.ndarray:
            args = [(i, x_current[i], lam_current) for i in range(p)]
            return np.vstack(pool.map(_process_predict, args, chunksize=1))

    else:
        raise ValueError(f"Unknown backend: {backend}")

    # Warm-up is excluded from iterative timing.
    _ = predict(x, lam)
    predictor_time = 0.0
    correction_time = 0.0
    t0 = time.perf_counter()

    for _ in range(iterations):
        start = time.perf_counter()
        x_tilde = predict(x, lam)
        predictor_time += time.perf_counter() - start

        start = time.perf_counter()
        lam_tilde = lam - beta * np.sum(x, axis=0)
        dx = x - x_tilde
        dl = lam - lam_tilde
        denominator = beta ** -1 + np.sum(1.0 / tau)
        s_lam = (beta ** -1 * dl - np.sum(dx, axis=0)) / denominator
        s_x = dx + s_lam[None, :] / tau[:, None]
        x -= alpha * s_x
        lam -= alpha * s_lam
        correction_time += time.perf_counter() - start

    elapsed = time.perf_counter() - t0
    if backend == "threads":
        executor.shutdown(wait=True)
    else:
        pool.close()
        pool.join()

    metric, objective, feasibility = merit(b, c, x)
    return {
        "backend": backend,
        "workers": workers,
        "iterations": iterations,
        "setup_seconds": setup,
        "iteration_seconds": elapsed,
        "local_seconds": predictor_time,
        "correction_seconds": correction_time,
        "merit": metric,
        "objective": objective,
        "feasibility": feasibility,
    }


def collect_environment() -> dict[str, object]:
    import numpy
    import scipy

    return {
        "platform": platform.platform(),
        "python": sys.version.replace("\n", " "),
        "logical_cpus_visible": os.cpu_count(),
        "numpy": numpy.__version__,
        "scipy": scipy.__version__,
        "blas_thread_environment": {
            name: os.environ.get(name)
            for name in (
                "OMP_NUM_THREADS",
                "OPENBLAS_NUM_THREADS",
                "MKL_NUM_THREADS",
                "NUMEXPR_NUM_THREADS",
            )
        },
    }


def run_benchmark(args: argparse.Namespace) -> pd.DataFrame:
    b, c, tau = generate_problem(
        p=args.blocks,
        ell=args.rows_per_block,
        n=args.variables_per_block,
        seed=args.seed,
    )
    rows: list[dict[str, object]] = []
    for backend in args.backends:
        for workers in args.workers:
            repetitions = []
            for rep in range(args.repetitions):
                print(f"run backend={backend} workers={workers} repetition={rep + 1}", flush=True)
                repetitions.append(
                    one_run(
                        b,
                        c,
                        tau,
                        workers,
                        backend,
                        iterations=args.iterations,
                        alpha=args.alpha,
                        beta=args.beta,
                    )
                )
            repetitions.sort(key=lambda row: float(row["iteration_seconds"]))
            median_row = repetitions[len(repetitions) // 2].copy()
            median_row["rep_times"] = ";".join(
                f"{float(row['iteration_seconds']):.9f}" for row in repetitions
            )
            rows.append(median_row)
            print(median_row, flush=True)

    frame = pd.DataFrame(rows)
    for backend in args.backends:
        base_rows = frame[(frame.backend == backend) & (frame.workers == 1)]
        if base_rows.empty:
            raise ValueError(f"Worker count 1 is required to compute speedup for {backend}.")
        base = float(base_rows.iteration_seconds.iloc[0])
        mask = frame.backend == backend
        frame.loc[mask, "speedup"] = base / frame.loc[mask, "iteration_seconds"]
        frame.loc[mask, "efficiency"] = (
            frame.loc[mask, "speedup"] / frame.loc[mask, "workers"]
        )
    return frame


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out-dir", type=Path, default=Path("."))
    parser.add_argument("--workers", nargs="+", type=int, default=[1, 2, 4])
    parser.add_argument(
        "--backends", nargs="+", choices=["threads", "processes"], default=["threads", "processes"]
    )
    parser.add_argument("--repetitions", type=int, default=3)
    parser.add_argument("--iterations", type=int, default=200)
    parser.add_argument("--blocks", type=int, default=16)
    parser.add_argument("--rows-per-block", type=int, default=1200)
    parser.add_argument("--variables-per-block", type=int, default=500)
    parser.add_argument("--seed", type=int, default=20260727)
    parser.add_argument("--alpha", type=float, default=1.5)
    parser.add_argument("--beta", type=float, default=1.0)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    args.out_dir.mkdir(parents=True, exist_ok=True)
    frame = run_benchmark(args)
    output = args.out_dir / "parallel_scaling_results.csv"
    frame.to_csv(output, index=False)
    (args.out_dir / "parallel_environment.json").write_text(
        json.dumps(collect_environment(), indent=2), encoding="utf-8"
    )
    print(frame.to_string(index=False))
    print(f"Wrote {output}")


if __name__ == "__main__":
    main()
