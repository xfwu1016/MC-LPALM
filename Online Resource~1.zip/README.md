# Online Resource 1: Reproducibility package

**Article:** A metric-compatible linearized relaxed parallel augmented Lagrangian method for composite convex learning  
**Target journal:** Numerical Algorithms  
**Authors:** Xiaofei Wu and Sheng Fu  
**Corresponding author:** Sheng Fu, School of Statistics and Data Science, LPMC, AAIS, and KLMDASR, Nankai University, Tianjin 300071, China (`fusheng@nankai.edu.cn`)

This archive contains the Python code, archived CSV outputs, and figure-generation scripts used in the manuscript. It does not redistribute the public LIBSVM `a9a` data file.

For a command-by-command workflow, platform notes, expected outputs, and troubleshooting, see `CODE_REPRODUCTION_GUIDE.txt`.

## Files

- `reproduce_experiments.py`: serial/vectorized synthetic and a9a experiments; regenerates Figs. 1--3 when the experiments are rerun.
- `reproduce_parallel_scaling.py`: shared-memory thread and single-host multi-process scaling experiment.
- `reproduce_sensitivity.py`: relaxation and penalty sensitivity experiment.
- `make_parallel_figures.py`: creates Figs. 4--6 from the scaling and sensitivity CSV files.
- `reproduce_all.py`: master driver for all experiments and figures.
- `smoke_test.py`: quick deterministic implementation checks.
- `environment_report.py`: records software versions and visible hardware information.
- `*_results.csv`: archived numerical outputs used in the manuscript.
- `requirements.txt`: minimum package versions.
- `requirements-lock.txt`: exact package versions used for the reported runs.

## Data

Download the original `a9a` file from the LIBSVM binary classification repository and save it as `a9a`. The expected checksum is:

```text
SHA-256: f5d5ffd8d865ff41328e7ee043e4b020816914ff6843ff15b98905ddbedce906
Rows: 32561
Features requested by the loader: 123
```

The main script can also download the file automatically when network access is available.

## Environment

The reported timing results were obtained in a Linux virtualized environment with five allocated CPU cores from an AMD EPYC 9V74 processor and approximately 6 GB memory. The exact software versions are in `requirements-lock.txt`. Internal BLAS threading is fixed to one for the scaling experiment to avoid nested parallelism.

The process backend uses the POSIX `fork` start method so that the large read-only arrays are inherited copy-on-write. Run the process benchmark on Linux or macOS. The thread benchmark and serial experiments are otherwise portable.

## Installation

A clean virtual environment is recommended:

```bash
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
python -m pip install --upgrade pip
python -m pip install -r requirements-lock.txt
```

## Quick validation

```bash
python smoke_test.py
python environment_report.py --out environment_report.json
```

## Reproduce all experiments

```bash
python reproduce_all.py --a9a-path ./a9a --out-dir ./recomputed
```

To skip the hardware-dependent scaling benchmark and use the archived scaling CSV:

```bash
python reproduce_all.py --a9a-path ./a9a --out-dir ./recomputed --skip-parallel
```

To omit the real-data experiment:

```bash
python reproduce_all.py --skip-a9a --out-dir ./recomputed
```

## Individual commands

```bash
python reproduce_experiments.py --mode synthetic --out-dir ./recomputed
python reproduce_experiments.py --mode a9a --a9a-path ./a9a --out-dir ./recomputed
python reproduce_parallel_scaling.py --out-dir ./recomputed
python reproduce_sensitivity.py --out-dir ./recomputed
python make_parallel_figures.py --data-dir ./recomputed --out-dir ./recomputed
```

## Reproducibility notes

- Random seeds, stopping tolerances, and default dimensions are fixed in the scripts.
- Iteration counts and terminal residuals should be reproducible up to small floating-point differences.
- The `wall_seconds` columns are elapsed wall-clock times measured with Python's high-resolution performance counter.
- Wall-clock times and speedups depend on the processor, BLAS implementation, memory bandwidth, scheduler, and system load.
- The single-host process experiment is not an MPI or multi-node network benchmark.
- The archived CSV files are the exact tabulated values used in the manuscript; rerunning on another machine is expected to change timing columns.
