#!/usr/bin/env python3
"""Master driver for all experiments and all six manuscript figures.

Examples
--------
python reproduce_all.py --a9a-path ./a9a --out-dir ./results
python reproduce_all.py --a9a-path ./a9a --out-dir ./results --skip-parallel
"""
from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

import reproduce_experiments as serial


def run_command(command: list[str], cwd: Path) -> None:
    print("+", " ".join(command), flush=True)
    subprocess.run(command, cwd=cwd, check=True)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--a9a-path", type=Path, default=Path("a9a"))
    parser.add_argument("--out-dir", type=Path, default=Path("results"))
    parser.add_argument("--skip-a9a", action="store_true")
    parser.add_argument("--skip-parallel", action="store_true")
    parser.add_argument("--parallel-repetitions", type=int, default=3)
    parser.add_argument("--parallel-iterations", type=int, default=200)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    script_dir = Path(__file__).resolve().parent
    out_dir = args.out_dir.resolve()
    out_dir.mkdir(parents=True, exist_ok=True)

    synthetic_df, synthetic_hist = serial.run_synthetic(out_dir)
    a9a_df = a9a_hist = None
    if not args.skip_a9a:
        a9a_df, a9a_hist = serial.run_a9a(args.a9a_path.resolve(), out_dir)
    serial.plot_figures(out_dir, synthetic_df, synthetic_hist, a9a_df, a9a_hist)

    run_command(
        [
            sys.executable,
            str(script_dir / "reproduce_sensitivity.py"),
            "--out-dir",
            str(out_dir),
        ],
        script_dir,
    )

    if not args.skip_parallel:
        run_command(
            [
                sys.executable,
                str(script_dir / "reproduce_parallel_scaling.py"),
                "--out-dir",
                str(out_dir),
                "--repetitions",
                str(args.parallel_repetitions),
                "--iterations",
                str(args.parallel_iterations),
            ],
            script_dir,
        )
    else:
        archived = script_dir / "parallel_scaling_results.csv"
        if archived.exists():
            (out_dir / archived.name).write_bytes(archived.read_bytes())
        else:
            raise FileNotFoundError(
                "--skip-parallel was requested, but no archived parallel_scaling_results.csv exists."
            )

    run_command(
        [
            sys.executable,
            str(script_dir / "make_parallel_figures.py"),
            "--data-dir",
            str(out_dir),
            "--out-dir",
            str(out_dir),
        ],
        script_dir,
    )
    run_command(
        [
            sys.executable,
            str(script_dir / "environment_report.py"),
            "--out",
            str(out_dir / "environment_report.json"),
        ],
        script_dir,
    )
    print(f"All requested outputs are in {out_dir}")


if __name__ == "__main__":
    main()
