ONLINE RESOURCE 1: REPRODUCTION CODE AND TABULATED OUTPUTS

Article: A metric-compatible linearized relaxed parallel augmented Lagrangian method for composite convex learning
Target journal: Numerical Algorithms
Authors: Xiaofei Wu and Sheng Fu
Corresponding author: Sheng Fu, School of Statistics and Data Science, LPMC, AAIS, and KLMDASR, Nankai University, Tianjin 300071, China, fusheng@nankai.edu.cn

See README.md for the complete file inventory, environment, checksum,
installation instructions, and exact reproduction commands.
The file CODE_REPRODUCTION_GUIDE.txt provides a command-by-command reproduction workflow.
