"""Rebuild Figure 1 from the archived selected-setting trajectory."""
from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-dir", type=Path, default=Path("."))
    parser.add_argument("--out-dir", type=Path, default=Path("."))
    args = parser.parse_args()
    frame = pd.read_csv(args.data_dir / "synthetic_p50_equal_budget_history.csv")
    args.out_dir.mkdir(parents=True, exist_ok=True)
    plt.rcParams.update({"font.size": 9, "pdf.fonttype": 42, "ps.fonttype": 42})
    fig, ax = plt.subplots(figsize=(6.4, 4.2))
    colors = {"MC-LPALM": "#1f77b4", "R2-PALM": "#9467bd",
              "PJADMM": "#d62728", "Direct Jacobi": "#7f7f7f"}
    markers = {"MC-LPALM": "o", "R2-PALM": "s", "PJADMM": "^",
               "Direct Jacobi": "D"}
    for method, group in frame.groupby("method", sort=False):
        merit = np.maximum(group.objective.to_numpy(float), group.feasibility.to_numpy(float))
        ax.semilogy(group.iterations, np.maximum(merit, 1e-20),
                    color=colors[method], marker=markers[method],
                    markevery=max(1, len(group) // 12), linewidth=1.5, label=method)
    ax.axhline(1e-6, color="black", linestyle="--", linewidth=0.9,
               label="stopping tolerance")
    ax.set_xlabel("Iteration")
    ax.set_ylabel("Objective-feasibility merit")
    ax.grid(True, which="both", linestyle=":", linewidth=0.6, alpha=0.7)
    ax.legend(frameon=True)
    fig.tight_layout()
    for extension, options in (("pdf", {}), ("eps", {}),
                               ("png", {"dpi": 220})):
        fig.savefig(args.out_dir / f"Fig1.{extension}", bbox_inches="tight", **options)
    plt.close(fig)


if __name__ == "__main__":
    main()
