"""Equal-screen-budget parameter comparison for the a9a consensus study.

Each method screens seven parameter configurations, validates its best three
with three repetitions, then evaluates the selected configuration in ten
fresh timing repetitions. All methods share initialization, stopping checks,
iteration limits, data, and timing scope.
"""
from __future__ import annotations

import argparse
import itertools
import json
import os
import sys
from pathlib import Path

for key in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ[key] = "1"

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
ESM = ROOT
sys.path.insert(0, str(ESM))
import reproduce_experiments as impl  # noqa: E402


def mc_candidates() -> list[dict[str, float]]:
    """A fixed seven-point discrete design covering each axis level."""
    alphas = (0.75, 1.0, 1.25, 1.5, 1.75)
    betas = (0.1, 0.2, 0.5, 1.0)
    tau_zs = (0.1, 0.25, 0.5, 1.0)
    alpha_idx = (0, 0, 1, 2, 2, 3, 4)
    beta_idx = (0, 1, 2, 3, 0, 1, 2)
    tau_idx = (0, 3, 2, 1, 0, 3, 2)
    candidates = [
        {"alpha": alphas[a], "beta": betas[b], "tau_z": tau_zs[t]}
        for a, b, t in zip(alpha_idx, beta_idx, tau_idx)
    ]
    assert len(candidates) == len({json.dumps(x, sort_keys=True) for x in candidates}) == 7
    return candidates


def execute(method: str, parts, x, y, reg, ref_obj, params: dict,
            maxit: int, gap_tol: float, res_tol: float):
    if method == "MC-LPALM":
        return impl.run_mc_consensus(parts, x, y, reg, ref_obj, **params,
                                     maxit=maxit, gap_tol=gap_tol, res_tol=res_tol)
    if method == "L-ADMM":
        return impl.run_linearized_admm(parts, x, y, reg, ref_obj, **params,
                                        maxit=maxit, gap_tol=gap_tol, res_tol=res_tol)
    return impl.run_exact_admm(parts, x, y, reg, ref_obj, **params,
                               maxit=maxit, gap_tol=gap_tol, res_tol=res_tol)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--a9a-path", type=Path, default=ROOT / "a9a")
    parser.add_argument("--out-dir", type=Path, default=ROOT / "tuning_a9a_equal_budget")
    parser.add_argument("--p-values", nargs="+", type=int, default=[4, 8, 16])
    args = parser.parse_args()
    data_path = args.a9a_path.resolve()
    out = args.out_dir.resolve()
    out.mkdir(parents=True, exist_ok=True)
    x, y = impl.load_a9a_scaled(data_path)
    _, grad0 = impl.logistic_value_grad(x, y, np.zeros(x.shape[1]), x.shape[0])
    reg = 0.05 * float(np.max(np.abs(grad0)))
    _, ref_obj, _ = impl.fista_reference(x, y, reg, maxit=20000, tol=1e-12)

    rhos = (0.01, 0.025, 0.05, 0.1, 0.2, 0.5, 1.0)
    gap_tol, res_tol, maxit = 5e-4, 1e-4, 3000
    all_final: list[dict] = []

    for p in args.p_values:
        parts = impl.partition_rows(x, y, p)
        candidates = [("MC-LPALM", params) for params in mc_candidates()]
        for method in ("L-ADMM", "QN-ADMM"):
            candidates.extend((method, {"rho": rho}) for rho in rhos)
        assert [sum(method == name for method, _ in candidates)
                for name in ("MC-LPALM", "L-ADMM", "QN-ADMM")] == [7, 7, 7]
        np.random.default_rng(2026 + p).shuffle(candidates)

        screen_rows = []
        for idx, (method, params) in enumerate(candidates):
            result = execute(method, parts, x, y, reg, ref_obj, params,
                             maxit, gap_tol, res_tol)
            row = {
                "p": p, "method": method, "parameters": json.dumps(params, sort_keys=True),
                "seconds": result.wall_seconds, "iterations": result.iterations,
                "gap": result.metric1, "residual": result.metric2,
                "status": result.status,
            }
            screen_rows.append(row)
            pd.DataFrame(screen_rows).to_csv(out / f"screen_p{p}.csv", index=False)
            if idx % 5 == 0 or idx == len(candidates) - 1:
                print(f"SCREEN p={p} {idx + 1}/{len(candidates)} {row}", flush=True)

        screen = pd.DataFrame(screen_rows)
        validation_rows = []
        finalists = {}
        for method in ("MC-LPALM", "L-ADMM", "QN-ADMM"):
            converged = screen[(screen.method == method) & (screen.status == "converged")]
            finalists[method] = converged.nsmallest(3, "seconds").parameters.tolist()
        order = [(method, param) for method, params in finalists.items() for param in params]
        for repetition in range(1, 4):
            shift = (repetition - 1) % len(order)
            for method, param_string in order[shift:] + order[:shift]:
                result = execute(method, parts, x, y, reg, ref_obj, json.loads(param_string),
                                 maxit, gap_tol, res_tol)
                validation_rows.append({
                    "p": p, "method": method, "parameters": param_string,
                    "repetition": repetition, "seconds": result.wall_seconds,
                    "iterations": result.iterations, "gap": result.metric1,
                    "residual": result.metric2, "status": result.status,
                })
            pd.DataFrame(validation_rows).to_csv(out / f"validation_p{p}.csv", index=False)

        validation = pd.DataFrame(validation_rows)
        medians = validation.groupby(["method", "parameters"], as_index=False).agg(
            median_seconds=("seconds", "median"),
            all_converged=("status", lambda values: bool((values == "converged").all())),
        )
        selected = {}
        for method in ("MC-LPALM", "L-ADMM", "QN-ADMM"):
            feasible = medians[(medians.method == method) & medians.all_converged]
            selected[method] = feasible.loc[feasible.median_seconds.idxmin(), "parameters"]

        method_order = list(selected)
        for repetition in range(1, 11):
            shift = (repetition - 1) % len(method_order)
            for method in method_order[shift:] + method_order[:shift]:
                param_string = selected[method]
                result = execute(method, parts, x, y, reg, ref_obj, json.loads(param_string),
                                 maxit, gap_tol, res_tol)
                all_final.append({
                    "p": p, "method": method, "parameters": param_string,
                    "repetition": repetition, "seconds": result.wall_seconds,
                    "iterations": result.iterations, "gap": result.metric1,
                    "residual": result.metric2, "status": result.status,
                })
                pd.DataFrame(all_final).to_csv(out / "final_10_runs.csv", index=False)
        print(f"SELECTED p={p}: " + json.dumps(selected, sort_keys=True), flush=True)

    final = pd.DataFrame(all_final)
    summary = final.groupby(["p", "method", "parameters"], as_index=False).agg(
        repetitions=("seconds", "size"), median_seconds=("seconds", "median"),
        q1_seconds=("seconds", lambda values: values.quantile(0.25)),
        q3_seconds=("seconds", lambda values: values.quantile(0.75)),
        median_iterations=("iterations", "median"),
        all_converged=("status", lambda values: bool((values == "converged").all())),
        max_gap=("gap", "max"), max_residual=("residual", "max"),
    )
    summary.to_csv(out / "final_summary.csv", index=False)
    print(summary.to_string(index=False))


if __name__ == "__main__":
    main()
