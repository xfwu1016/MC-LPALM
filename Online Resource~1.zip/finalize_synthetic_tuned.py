"""Independently retime the selected balanced-grid synthetic configurations."""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path

for key in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ[key] = "1"

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
ESM = ROOT
TUNING = Path(__file__).resolve().parent / "tuning_synthetic"
OUT = Path(__file__).resolve().parent / "tuning_synthetic_equal_budget"
sys.path.insert(0, str(ESM))
import reproduce_experiments as impl  # noqa: E402


def execute(method: str, problem, params: dict):
    if method == "MC-LPALM":
        return impl.run_mc_exchange(problem, **params, tol=1e-6, maxit=20000)
    if method == "R2-PALM":
        return impl.run_r2_exchange(problem, **params, tol=1e-6, maxit=20000)
    return impl.run_pjadmm_exchange(problem, **params, tol=1e-6, maxit=20000)


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    params_by_case: dict[tuple[int, str], str] = {}
    for p in (10, 20, 50, 100):
        screen = pd.read_csv(TUNING / f"validation_p{p}.csv")
        med = screen.groupby(["method", "parameters"], as_index=False).agg(
            median_seconds=("seconds", "median"),
            all_converged=("status", lambda values: bool((values == "converged").all())),
        )
        for method in ("MC-LPALM", "R2-PALM", "PJADMM"):
            candidates = med[(med.method == method) & med.all_converged]
            selected = candidates.loc[candidates.median_seconds.idxmin(), "parameters"]
            params_by_case[(p, method)] = selected

    rows = []
    methods = ("MC-LPALM", "R2-PALM", "PJADMM")
    for p in (10, 20, 50, 100):
        problem = impl.generate_exchange_problem(p)
        for repetition in range(1, 11):
            shift = (repetition - 1) % len(methods)
            for method in methods[shift:] + methods[:shift]:
                param_string = params_by_case[(p, method)]
                result = execute(method, problem, json.loads(param_string))
                row = {
                    "p": p, "method": method, "parameters": param_string,
                    "repetition": repetition, "seconds": result.wall_seconds,
                    "iterations": result.iterations, "objective": result.metric1,
                    "feasibility": result.metric2, "status": result.status,
                }
                rows.append(row)
            pd.DataFrame(rows).to_csv(OUT / "final_10_runs.csv", index=False)
        print(f"FINISHED p={p}", flush=True)

    raw = pd.DataFrame(rows)
    raw.to_csv(OUT / "final_10_runs.csv", index=False)
    summary = raw.groupby(["p", "method", "parameters"], as_index=False).agg(
        repetitions=("seconds", "size"), median_seconds=("seconds", "median"),
        q1_seconds=("seconds", lambda values: values.quantile(0.25)),
        q3_seconds=("seconds", lambda values: values.quantile(0.75)),
        median_iterations=("iterations", "median"),
        median_objective=("objective", "median"),
        median_feasibility=("feasibility", "median"),
        all_converged=("status", lambda values: bool((values == "converged").all())),
    )
    summary.to_csv(OUT / "final_summary.csv", index=False)
    print(summary.to_string(index=False))


if __name__ == "__main__":
    main()
