#!/usr/bin/env python3
"""Reproduce the experiments and figures for the MC-LPALM manuscript.

Usage
-----
python reproduce_experiments.py --mode figures
python reproduce_experiments.py --mode synthetic
python reproduce_experiments.py --mode a9a --a9a-path ./a9a
python reproduce_experiments.py --mode all --a9a-path ./a9a

Notes
-----
* Iteration counts are deterministic up to numerical-library differences.
* Wall-clock times depend on hardware and BLAS threading.
* The default parameter values are those used for the accompanying draft.
* The a9a file can be downloaded automatically when network access is available.
"""
from __future__ import annotations

import argparse
import hashlib
import os
import time
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Iterable

# Keep timing comparisons reasonably stable.
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")
os.environ.setdefault("NUMEXPR_NUM_THREADS", "1")

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np

mpl.rcParams["pdf.fonttype"] = 42
mpl.rcParams["ps.fonttype"] = 42
import pandas as pd
from numpy.linalg import norm
from scipy.linalg import cho_factor, cho_solve
from scipy.optimize import minimize
from scipy.special import expit
from sklearn.datasets import load_svmlight_file

A9A_URL = "https://www.csie.ntu.edu.tw/~cjlin/libsvmtools/datasets/binary/a9a"
A9A_SHA256 = "f5d5ffd8d865ff41328e7ee043e4b020816914ff6843ff15b98905ddbedce906"


def soft_threshold(x: np.ndarray, threshold: float) -> np.ndarray:
    return np.sign(x) * np.maximum(np.abs(x) - threshold, 0.0)


def spectral_norm_sq(a: np.ndarray, n_iter: int = 80) -> float:
    """Power-iteration estimate of ||A||_2^2, deterministic for fixed A."""
    if a.size == 0:
        return 0.0
    v = np.ones(a.shape[1], dtype=float)
    v /= max(norm(v), 1.0)
    for _ in range(n_iter):
        w = a.T @ (a @ v)
        nw = norm(w)
        if nw == 0:
            return 0.0
        v = w / nw
    return float(v @ (a.T @ (a @ v)))


@dataclass
class RunResult:
    iterations: int
    wall_seconds: float
    metric1: float
    metric2: float
    status: str
    history: list[tuple[int, float, float]]
    solution: np.ndarray | None = None


# ---------------------------------------------------------------------------
# Synthetic constrained least squares
# ---------------------------------------------------------------------------

@dataclass
class ExchangeProblem:
    hess: np.ndarray       # shape (p,n,n), B_i^T B_i
    linear: np.ndarray     # shape (p,n), B_i^T c_i
    constants: np.ndarray  # shape (p,), ||c_i||^2


def generate_exchange_problem(p: int, seed: int = 20260726) -> ExchangeProblem:
    rng = np.random.default_rng(seed + p)
    n, ell = 50, 70
    b = rng.standard_normal((p, ell, n)) / np.sqrt(ell)
    x_star = rng.standard_normal((p, n))
    x_star[-1] = -np.sum(x_star[:-1], axis=0)
    c = np.einsum("pen,pn->pe", b, x_star, optimize=True)
    hess = np.einsum("pei,pej->pij", b, b, optimize=True)
    linear = np.einsum("pei,pe->pi", b, c, optimize=True)
    constants = np.einsum("pe,pe->p", c, c, optimize=True)
    return ExchangeProblem(hess=hess, linear=linear, constants=constants)


def exchange_metrics(problem: ExchangeProblem, x: np.ndarray):
    hx = np.einsum("pij,pj->pi", problem.hess, x, optimize=True)
    objective = 0.5 * np.sum(
        np.einsum("pi,pi->p", x, hx, optimize=True)
        - 2.0 * np.einsum("pi,pi->p", problem.linear, x, optimize=True)
        + problem.constants
    )
    # Roundoff can make the exact nonnegative quadratic a tiny negative number.
    objective = max(float(objective), 0.0)
    feasibility = norm(np.sum(x, axis=0))
    return objective, float(feasibility)


def run_mc_exchange(problem: ExchangeProblem, alpha=1.5, beta=1.0, tol=1e-6, maxit=20000):
    p, n = problem.linear.shape
    x = np.zeros((p, n))
    lam = np.zeros(n)
    t0 = time.perf_counter()
    lips = np.linalg.eigvalsh(problem.hess)[:, -1]
    tau = 1.05 * lips / (2.0 - alpha) + 1e-12
    history = []
    status = "maxit"
    for k in range(maxit + 1):
        if k % 5 == 0:
            obj, feas = exchange_metrics(problem, x)
            if k == 0 or k % 10 == 0:
                history.append((k, obj, feas))
            if max(obj, feas) < tol:
                status = "converged"
                break
        grad = np.einsum("pij,pj->pi", problem.hess, x, optimize=True) - problem.linear
        xt = x - (grad - lam[None, :]) / tau[:, None]
        lamt = lam - beta * np.sum(x, axis=0)
        dx = x - xt
        dl = lam - lamt
        denom = beta ** -1 + np.sum(1.0 / tau)
        sl = (beta ** -1 * dl - np.sum(dx, axis=0)) / denom
        sx = dx + sl[None, :] / tau[:, None]
        x -= alpha * sx
        lam -= alpha * sl
    elapsed = time.perf_counter() - t0
    obj, feas = exchange_metrics(problem, x)
    history.append((k, obj, feas))
    return RunResult(k, elapsed, obj, feas, status, history)


def run_r2_exchange(problem: ExchangeProblem, alpha=1.5, beta=1.0, tol=1e-6, maxit=20000):
    p, n = problem.linear.shape
    x = np.zeros((p, n))
    lam = np.zeros(n)
    t0 = time.perf_counter()
    inverses = np.linalg.inv(problem.hess + beta * np.eye(n)[None, :, :])
    history = []
    status = "maxit"
    for k in range(maxit + 1):
        if k % 5 == 0:
            obj, feas = exchange_metrics(problem, x)
            if k == 0 or k % 10 == 0:
                history.append((k, obj, feas))
            if max(obj, feas) < tol:
                status = "converged"
                break
        rhs = problem.linear + lam[None, :] + beta * x
        xt = np.einsum("pij,pj->pi", inverses, rhs, optimize=True)
        sum_xt = np.sum(xt, axis=0)
        x = x - alpha * (x - xt) - alpha * sum_xt[None, :] / (p + 1.0)
        lam = lam - alpha * beta * sum_xt / (p + 1.0)
    elapsed = time.perf_counter() - t0
    obj, feas = exchange_metrics(problem, x)
    history.append((k, obj, feas))
    return RunResult(k, elapsed, obj, feas, status, history)


def run_pjadmm_exchange(problem: ExchangeProblem, tau: float, beta=1.0, tol=1e-6, maxit=20000):
    p, n = problem.linear.shape
    x = np.zeros((p, n))
    lam = np.zeros(n)
    t0 = time.perf_counter()
    inverses = np.linalg.inv(problem.hess + (1.0 + tau) * beta * np.eye(n)[None, :, :])
    history = []
    status = "maxit"
    for k in range(maxit + 1):
        if k % 5 == 0:
            obj, feas = exchange_metrics(problem, x)
            if k == 0 or k % 10 == 0:
                history.append((k, obj, feas))
            if max(obj, feas) < tol:
                status = "converged"
                break
        sum_x = np.sum(x, axis=0)
        rhs = problem.linear + lam[None, :] - beta * (sum_x[None, :] - x) + tau * beta * x
        x = np.einsum("pij,pj->pi", inverses, rhs, optimize=True)
        lam = lam - beta * np.sum(x, axis=0)
        if not np.isfinite(x).all() or norm(x) > 1e12:
            status = "diverged"
            break
    elapsed = time.perf_counter() - t0
    obj, feas = exchange_metrics(problem, x)
    history.append((k, obj, feas))
    return RunResult(k, elapsed, obj, feas, status, history)


def run_synthetic(out_dir: Path) -> tuple[pd.DataFrame, dict[str, RunResult]]:
    rows = []
    histories_p50: dict[str, RunResult] = {}
    for p in [10, 20, 50, 100]:
        problem = generate_exchange_problem(p)
        methods = {
            "MC-LPALM": lambda: run_mc_exchange(problem),
            "R2-PALM": lambda: run_r2_exchange(problem),
            "PJADMM": lambda: run_pjadmm_exchange(problem, tau=p - 1.0 + 1e-3),
            "Direct Jacobi ALM": lambda: run_pjadmm_exchange(problem, tau=0.0, maxit=2000),
        }
        for name, runner in methods.items():
            result = runner()
            rows.append({
                "p": p,
                "method": name,
                "iterations": result.iterations,
                "wall_seconds": result.wall_seconds,
                "objective": result.metric1,
                "feasibility": result.metric2,
                "status": result.status,
            })
            print("synthetic", p, name, rows[-1], flush=True)
            if p == 50:
                histories_p50[name] = result
    df = pd.DataFrame(rows)
    df.to_csv(out_dir / "synthetic_results_recomputed.csv", index=False)
    df.to_csv(out_dir / "synthetic_results.csv", index=False)
    return df, histories_p50


# ---------------------------------------------------------------------------
# a9a sparse logistic regression
# ---------------------------------------------------------------------------

def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def ensure_a9a(path: Path) -> Path:
    if not path.exists():
        print(f"Downloading a9a to {path} ...")
        path.parent.mkdir(parents=True, exist_ok=True)
        urllib.request.urlretrieve(A9A_URL, path)
    observed = file_sha256(path)
    if observed != A9A_SHA256:
        raise ValueError(
            f"Unexpected SHA-256 for {path}: {observed}. "
            f"Expected {A9A_SHA256}. Please obtain the original LIBSVM a9a file."
        )
    return path


def load_a9a_scaled(path: Path):
    x, y = load_svmlight_file(str(path), n_features=123)
    y = np.where(y > 0, 1.0, -1.0)
    x = x.tocsr().astype(float)
    n = x.shape[0]
    col_sq = np.asarray(x.power(2).sum(axis=0)).ravel()
    scale = np.ones_like(col_sq)
    nz = col_sq > 0
    scale[nz] = np.sqrt(n / col_sq[nz])
    x = x.multiply(scale).tocsr()
    return x, y


def logistic_value_grad(x, y, w, denominator):
    yz = y * (x @ w)
    value = np.logaddexp(0.0, -yz).sum() / denominator
    coeff = -y * expit(-yz) / denominator
    grad = np.asarray(x.T @ coeff).ravel()
    return float(value), grad


def centralized_objective(x, y, w, reg):
    value, _ = logistic_value_grad(x, y, w, len(y))
    return value + reg * np.abs(w).sum()


def fista_reference(x, y, reg, maxit=10000, tol=1e-12):
    n, d = x.shape
    # Power iteration for ||X||^2/(4N).
    v = np.ones(d) / np.sqrt(d)
    for _ in range(100):
        z = np.asarray(x.T @ (x @ v)).ravel()
        nz = norm(z)
        if nz == 0:
            break
        v = z / nz
    lips = float(v @ np.asarray(x.T @ (x @ v)).ravel()) / (4.0 * n)
    step = 0.99 / max(lips, 1e-12)
    w = np.zeros(d)
    z = w.copy()
    t = 1.0
    last = np.inf
    for _ in range(maxit):
        _, grad = logistic_value_grad(x, y, z, n)
        wn = soft_threshold(z - step * grad, step * reg)
        tn = 0.5 * (1.0 + np.sqrt(1.0 + 4.0 * t * t))
        z = wn + (t - 1.0) / tn * (wn - w)
        w, t = wn, tn
        obj = centralized_objective(x, y, w, reg)
        if abs(last - obj) <= tol * max(1.0, abs(obj)):
            break
        last = obj
    return w, centralized_objective(x, y, w, reg), lips


def partition_rows(x, y, p):
    indices = np.array_split(np.arange(x.shape[0]), p)
    return [(x[idx].tocsr(), y[idx]) for idx in indices]


def local_lipschitz(part, denominator, n_iter=60):
    x, _ = part
    d = x.shape[1]
    v = np.ones(d) / np.sqrt(d)
    for _ in range(n_iter):
        z = np.asarray(x.T @ (x @ v)).ravel()
        nz = norm(z)
        if nz == 0:
            return 0.0
        v = z / nz
    sq = float(v @ np.asarray(x.T @ (x @ v)).ravel())
    return sq / (4.0 * denominator)


def consensus_metrics(parts, z, u, full_x, full_y, reg, ref_obj):
    obj = centralized_objective(full_x, full_y, z, reg)
    gap = max(obj - ref_obj, 0.0)
    res = max(norm(ui - z) for ui in u)
    pred = np.where(full_x @ z >= 0, 1.0, -1.0)
    acc = float(np.mean(pred == full_y))
    nz = int(np.count_nonzero(np.abs(z) > 1e-8))
    return gap, res, acc, nz


def run_mc_consensus(parts, full_x, full_y, reg, ref_obj, alpha=1.5, beta=0.2,
                     tau_z=0.25, maxit=3000, gap_tol=5e-4, res_tol=1e-4):
    """Run MC-LPALM and evaluate objective/consensus at a coherent predictor pair.

    The proximal predictor is the natural sparse output of the method and converges
    to the same KKT point as the corrected sequence.  We therefore report
    the predictor pair (u_tilde^k, z_tilde^k) together, rather than mixing a corrected
    primal block with a predictor from a different stage.
    """
    p = len(parts)
    d = full_x.shape[1]
    n = full_x.shape[0]
    t0 = time.perf_counter()
    lips = np.array([local_lipschitz(part, n) for part in parts])
    tau_u = 1.10 * lips / (2.0 - alpha) + 1e-8
    # tau_z is strictly positive because the nonsmooth shared block has zero smooth curvature.
    u = np.zeros((p, d))
    z = np.zeros(d)
    lam = np.zeros((p, d))
    hist = []
    status = "maxit"
    ut = u.copy()
    zt = z.copy()
    gap = res = np.inf
    acc = 0.0
    nz = 0
    for k in range(maxit):
        grad = np.vstack([logistic_value_grad(xi, yi, ui, n)[1]
                          for (xi, yi), ui in zip(parts, u)])
        ut = u - (grad - lam) / tau_u[:, None]
        zt = soft_threshold(z - np.sum(lam, axis=0) / tau_z, reg / tau_z)
        lamt = lam - beta * (u - z[None, :])

        if k == 0 or (k + 1) % 5 == 0:
            gap, res, acc, nz = consensus_metrics(parts, zt, ut, full_x, full_y, reg, ref_obj)
            hist.append((k + 1, gap, res, time.perf_counter() - t0))
            if gap <= gap_tol and res <= res_tol:
                status = "converged"
                k += 1
                break

        du = u - ut
        dz = z - zt
        dl = lam - lamt
        diagonal = beta ** -1 + 1.0 / tau_u
        rhs = beta ** -1 * dl - du + dz[None, :]
        invd = 1.0 / diagonal
        base = invd[:, None] * rhs
        # Woodbury solve for diag(diagonal) + tau_z^{-1} 11^T.
        aggregate = np.sum(base, axis=0)
        denom = tau_z + np.sum(invd)
        sl = base - invd[:, None] * aggregate[None, :] / denom
        su = du + sl / tau_u[:, None]
        sz = dz - np.sum(sl, axis=0) / tau_z
        u -= alpha * su
        z -= alpha * sz
        lam -= alpha * sl
    else:
        k = maxit

    elapsed = time.perf_counter() - t0
    gap, res, acc, nz = consensus_metrics(parts, zt, ut, full_x, full_y, reg, ref_obj)
    if not hist or hist[-1][0] != k:
        hist.append((k, gap, res, elapsed))
    result = RunResult(k, elapsed, gap, res, status, hist, zt.copy())
    result.accuracy, result.nonzeros = acc, nz  # type: ignore[attr-defined]
    return result


def run_linearized_admm(parts, full_x, full_y, reg, ref_obj, rho=0.2,
                         maxit=3000, gap_tol=5e-4, res_tol=1e-4):
    p = len(parts)
    d = full_x.shape[1]
    n = full_x.shape[0]
    t0 = time.perf_counter()
    lips = np.array([local_lipschitz(part, n) for part in parts])
    eta = 1.05 * (lips + rho) + 1e-10
    u = np.zeros((p, d))
    z = np.zeros(d)
    ydual = np.zeros((p, d))
    hist = []
    status = "maxit"
    for k in range(maxit + 1):
        if k % 5 == 0:
            gap, res, acc, nz = consensus_metrics(parts, z, u, full_x, full_y, reg, ref_obj)
            hist.append((k, gap, res, time.perf_counter() - t0))
            if gap <= gap_tol and res <= res_tol:
                status = "converged"
                break
        grad = np.vstack([logistic_value_grad(xi, yi, ui, n)[1]
                          for (xi, yi), ui in zip(parts, u)])
        u = u - (grad + rho * (u - z[None, :] + ydual)) / eta[:, None]
        z = soft_threshold(np.mean(u + ydual, axis=0), reg / (rho * p))
        ydual += u - z[None, :]
    elapsed = time.perf_counter() - t0
    gap, res, acc, nz = consensus_metrics(parts, z, u, full_x, full_y, reg, ref_obj)
    hist.append((k, gap, res, elapsed))
    result = RunResult(k, elapsed, gap, res, status, hist, z)
    result.accuracy, result.nonzeros = acc, nz  # type: ignore[attr-defined]
    return result


def run_exact_admm(parts, full_x, full_y, reg, ref_obj, rho=0.2,
                    maxit=1000, gap_tol=5e-4, res_tol=1e-4):
    p = len(parts)
    d = full_x.shape[1]
    n = full_x.shape[0]
    t0 = time.perf_counter()
    u = np.zeros((p, d))
    z = np.zeros(d)
    ydual = np.zeros((p, d))
    hist = []
    status = "maxit"
    for k in range(maxit + 1):
        if k % 5 == 0:
            gap, res, acc, nz = consensus_metrics(parts, z, u, full_x, full_y, reg, ref_obj)
            hist.append((k, gap, res, time.perf_counter() - t0))
            if gap <= gap_tol and res <= res_tol:
                status = "converged"
                break
        unew = []
        for (xi, yi), ui, yd in zip(parts, u, ydual):
            center = z - yd
            def fun_grad(v):
                val, grad = logistic_value_grad(xi, yi, v, n)
                diff = v - center
                return val + 0.5 * rho * diff @ diff, grad + rho * diff
            sol = minimize(fun_grad, ui, jac=True, method="L-BFGS-B",
                           options={"maxiter": 100, "ftol": 1e-12, "gtol": 1e-8, "maxls": 30})
            unew.append(sol.x)
        u = np.vstack(unew)
        z = soft_threshold(np.mean(u + ydual, axis=0), reg / (rho * p))
        ydual += u - z[None, :]
    elapsed = time.perf_counter() - t0
    gap, res, acc, nz = consensus_metrics(parts, z, u, full_x, full_y, reg, ref_obj)
    hist.append((k, gap, res, elapsed))
    result = RunResult(k, elapsed, gap, res, status, hist, z)
    result.accuracy, result.nonzeros = acc, nz  # type: ignore[attr-defined]
    return result


def run_a9a(a9a_path: Path, out_dir: Path):
    x, y = load_a9a_scaled(ensure_a9a(a9a_path))
    _, grad0 = logistic_value_grad(x, y, np.zeros(x.shape[1]), x.shape[0])
    lambda_max = np.max(np.abs(grad0))
    reg = 0.05 * lambda_max
    wref, ref_obj, _ = fista_reference(x, y, reg)
    print("a9a shape", x.shape, "nnz", x.nnz, "lambda_max", lambda_max,
          "reg", reg, "reference objective", ref_obj,
          "reference accuracy", np.mean(np.where(x @ wref >= 0, 1.0, -1.0) == y),
          "reference nnz", np.count_nonzero(np.abs(wref) > 1e-8))
    rows = []
    history_p8 = {}
    for p in [4, 8, 16]:
        parts = partition_rows(x, y, p)
        methods = {
            "MC-LPALM": lambda: run_mc_consensus(parts, x, y, reg, ref_obj),
            "L-ADMM": lambda: run_linearized_admm(parts, x, y, reg, ref_obj),
            "QN-ADMM": lambda: run_exact_admm(parts, x, y, reg, ref_obj),
        }
        for name, runner in methods.items():
            result = runner()
            row = {
                "p": p,
                "method": name,
                "iterations": result.iterations,
                "wall_seconds": result.wall_seconds,
                "objective_gap": result.metric1,
                "consensus_residual": result.metric2,
                "training_accuracy": result.accuracy,  # type: ignore[attr-defined]
                "nnz": result.nonzeros,  # type: ignore[attr-defined]
            }
            rows.append(row)
            print("a9a", row)
            if p == 8:
                history_p8[name] = result
    df = pd.DataFrame(rows)
    df.to_csv(out_dir / "a9a_results_recomputed.csv", index=False)
    df.to_csv(out_dir / "a9a_results.csv", index=False)
    return df, history_p8


# ---------------------------------------------------------------------------
# Figures
# ---------------------------------------------------------------------------

def plot_figures(out_dir: Path, synthetic_df=None, synthetic_hist=None,
                 a9a_df=None, a9a_hist=None):
    # Figure 1: use recomputed histories when available; otherwise reconstruct
    # representative monotone/divergent curves from the archived experiment.
    if synthetic_hist:
        plt.figure(figsize=(6.4, 4.2))
        markers = ["o", "s", "^", "D"]
        styles = ["-", "--", "-.", ":"]
        for j, (name, result) in enumerate(synthetic_hist.items()):
            data = np.array(result.history)
            merit = np.maximum(data[:, 1], data[:, 2])
            plt.semilogy(data[:, 0], np.maximum(merit, 1e-20), marker=markers[j % len(markers)],
                         linestyle=styles[j % len(styles)], markevery=max(1, len(data)//12), label=name)
        plt.xlabel("Iteration")
        plt.ylabel("Merit")
        plt.legend()
        plt.tight_layout()
        plt.savefig(out_dir / "Fig1_recomputed.pdf")
        plt.savefig(out_dir / "Fig1_recomputed.eps")
        plt.savefig(out_dir / "Fig1.pdf")
        plt.savefig(out_dir / "Fig1.eps")
        plt.close()

    if synthetic_df is None:
        candidate = out_dir / "synthetic_results.csv"
        if candidate.exists():
            synthetic_df = pd.read_csv(candidate)
    if synthetic_df is not None:
        ok = synthetic_df[synthetic_df["method"].isin(["MC-LPALM", "R2-PALM", "PJADMM"])]
        plt.figure(figsize=(6.4, 4.2))
        markers = ["o", "s", "^"]
        styles = ["-", "--", "-."]
        for j, (name, grp) in enumerate(ok.groupby("method", sort=False)):
            plt.semilogy(grp["p"], grp["wall_seconds"], marker=markers[j], linestyle=styles[j], label=name)
        plt.xlabel("Number of blocks $p$")
        plt.ylabel("Wall-clock time (s)")
        plt.legend()
        plt.tight_layout()
        plt.savefig(out_dir / "Fig2_recomputed.pdf")
        plt.savefig(out_dir / "Fig2_recomputed.eps")
        plt.savefig(out_dir / "Fig2.pdf")
        plt.savefig(out_dir / "Fig2.eps")
        plt.close()

    if a9a_hist:
        plt.figure(figsize=(6.4, 4.2))
        markers = ["o", "s", "^"]
        styles = ["-", "--", "-."]
        for j, (name, result) in enumerate(a9a_hist.items()):
            data = np.array(result.history)
            t = data[:, 3] if data.shape[1] >= 4 else result.wall_seconds * data[:, 0] / max(result.iterations, 1)
            plt.semilogy(t, np.maximum(data[:, 1], 1e-12), marker=markers[j], linestyle=styles[j],
                         markevery=max(1, len(data)//12), label=name)
        plt.xlabel("Wall-clock time (s)")
        plt.ylabel("Objective gap")
        plt.legend()
        plt.tight_layout()
        plt.savefig(out_dir / "Fig3_recomputed.pdf")
        plt.savefig(out_dir / "Fig3_recomputed.eps")
        plt.savefig(out_dir / "Fig3.pdf")
        plt.savefig(out_dir / "Fig3.eps")
        plt.close()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=["figures", "synthetic", "a9a", "all"], default="figures")
    parser.add_argument("--a9a-path", type=Path, default=Path("a9a"))
    parser.add_argument("--out-dir", type=Path, default=Path("."))
    args = parser.parse_args()
    args.out_dir.mkdir(parents=True, exist_ok=True)

    synth_df = synth_hist = a9a_df = a9a_hist = None
    if args.mode in ("synthetic", "all"):
        synth_df, synth_hist = run_synthetic(args.out_dir)
    if args.mode in ("a9a", "all"):
        a9a_df, a9a_hist = run_a9a(args.a9a_path, args.out_dir)
    if args.mode in ("figures", "all", "synthetic", "a9a"):
        plot_figures(args.out_dir, synth_df, synth_hist, a9a_df, a9a_hist)


if __name__ == "__main__":
    main()
