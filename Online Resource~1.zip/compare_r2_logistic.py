"""Direct MC-LPALM / R2-PALM / PJADMM comparisons on sparse logistic consensus.

R2-PALM implements He et al. (2023), equations (3.2) and (3.5), in
image variables. A common offset compresses its image states to O(p*d)
storage; this is algebraic compression, not projection of the correction.
All three methods are assessed at their primal predictors every five rounds.
All times include algorithm-specific setup, local solves, diagnostics and
correction; loading, partitioning, reference calculation and tuning are outside.
"""
from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import os
import platform
import time
from concurrent.futures import ThreadPoolExecutor
from contextlib import contextmanager
from pathlib import Path

for name in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS",
             "NUMEXPR_NUM_THREADS"):
    os.environ[name] = "1"

import numpy as np
import pandas as pd
import scipy
from scipy.optimize import minimize
from scipy.special import expit
from sklearn.datasets import load_svmlight_file
from threadpoolctl import threadpool_limits

DATASETS = {"a9a": ("a9a", 123), "phishing": ("phishing", 68),
            "w8a": ("w8a", 300), "ijcnn1": ("ijcnn1.bz2", 22)}
ALPHAS = (0.75, 1.0, 1.25, 1.5, 1.75)
BETAS = (0.01, 0.025, 0.05, 0.1, 0.2, 0.5, 1.0)
METHODS = ("MC-LPALM", "R2-PALM", "PJADMM")
def proximal_candidates(p):
    return (0.501, 1.0, 2.0, 0.75 * (p + 1) - 1 + 1e-3, p + 1e-3)
TAU_Z = 0.5


@contextmanager
def timing_lock(out):
    """Serialize timing drivers sharing one output directory."""
    out.mkdir(parents=True, exist_ok=True)
    with (out / ".timing.lock").open("a+b") as handle:
        if handle.tell() == 0:
            handle.write(b"0")
            handle.flush()
        handle.seek(0)
        if os.name == "nt":
            import msvcrt
            while True:
                try:
                    msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
                    break
                except OSError:
                    time.sleep(0.25)
            try:
                yield
            finally:
                handle.seek(0)
                msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
        else:
            import fcntl
            fcntl.flock(handle.fileno(), fcntl.LOCK_EX)
            try:
                yield
            finally:
                fcntl.flock(handle.fileno(), fcntl.LOCK_UN)


def threshold(v, t):
    return np.sign(v) * np.maximum(np.abs(v) - t, 0.0)


class Loss:
    def __init__(self, x, y, denominator):
        self.x, self.xt, self.y, self.denominator = x, x.T.tocsr(), y, denominator

    def value_grad(self, v):
        margin = self.y * (self.x @ v)
        value = np.logaddexp(0, -margin).sum() / self.denominator
        grad = self.xt @ (-self.y * expit(-margin) / self.denominator)
        return float(value), np.asarray(grad).ravel()

    def curvature(self):
        gram = self.xt @ self.x
        bound = float(np.asarray(abs(gram).sum(axis=1)).ravel().max())
        return float(np.nextafter(bound, np.inf)) / (4 * self.denominator)


def load_problem(name, data_dir, out):
    filename, features = DATASETS[name]
    path = data_dir / filename
    x, y = load_svmlight_file(str(path), n_features=features)
    x = x.tocsr().astype(float)
    y = np.where(y > 0, 1.0, -1.0)
    n = len(y)
    squares = np.asarray(x.power(2).sum(axis=0)).ravel()
    scales = np.ones(features)
    scales[squares > 0] = np.sqrt(n / squares[squares > 0])
    x = x.multiply(scales).tocsr()
    full = Loss(x, y, n)
    reg = 0.05 * np.max(np.abs(full.value_grad(np.zeros(features))[1]))
    cache_path = out / f"reference_{name}.json"
    data_hash = hashlib.sha256(path.read_bytes()).hexdigest()
    if cache_path.exists():
        meta = json.loads(cache_path.read_text())
        if meta["dataset_sha256"] == data_hash:
            return x, y, full, reg, meta["reference_objective"]
    lips = full.curvature()
    step = 0.99 / lips
    w, z, t = np.zeros(features), np.zeros(features), 1.0
    kkt = np.inf
    for k in range(1, 100001):
        grad = full.value_grad(z)[1]
        wn = threshold(z - step * grad, step * reg)
        tn = (1 + np.sqrt(1 + 4 * t * t)) / 2
        if np.dot(z - wn, wn - w) > 0:
            z, tn = wn.copy(), 1.0
        else:
            z = wn + (t - 1) / tn * (wn - w)
        w, t = wn, tn
        if k % 100 == 0:
            value, grad = full.value_grad(w)
            subgrad = np.where(w != 0, grad + reg * np.sign(w),
                               np.sign(grad) * np.maximum(np.abs(grad) - reg, 0))
            kkt = float(np.max(np.abs(subgrad)))
            if kkt <= 1e-10:
                break
    if kkt > 1e-9:
        raise RuntimeError(f"Reference did not reach its stationarity target: {kkt}")
    ref = full.value_grad(w)[0] + reg * np.abs(w).sum()
    meta = dict(dataset=name, n=n, d=features, nnz=int(x.nnz),
                dataset_sha256=data_hash, regularization=float(reg),
                reference_objective=float(ref), reference_kkt_inf=kkt,
                reference_iterations=k, reference_solution=w.tolist())
    cache_path.write_text(json.dumps(meta, indent=2))
    print("REFERENCE", name, ref, kkt, k, flush=True)
    return x, y, full, reg, float(ref)


def parts_for(x, y, p):
    return [Loss(x[index].tocsr(), y[index], len(y))
            for index in np.array_split(np.arange(len(y)), p)]


def run(method, parts, full, reg, ref, alpha, beta, gap_tol=5e-4,
        res_tol=1e-4, maxit=20000, workers=1, inner_tol=1e-8, tau_value=1.0):
    p, d = len(parts), full.x.shape[1]
    t0 = time.perf_counter()
    u, z, lam = np.zeros((p, d)), np.zeros(d), np.zeros((p, d))
    common = np.zeros((p, d))
    warm = np.zeros((p, d))
    proximal_tau = tau_value if method == "PJADMM" else np.nan
    executor = ThreadPoolExecutor(max_workers=workers) if workers > 1 else None
    if method == "MC-LPALM":
        tau = 1.10 * np.array([loss.curvature() for loss in parts]) / (2 - alpha) + 1e-8
        invd = 1.0 / (beta ** -1 + 1.0 / tau)
        denom = TAU_Z + invd.sum()
    setup = time.perf_counter() - t0
    local_seconds = correction_seconds = diagnostics_seconds = 0.0
    gradients = inner_iterations = failed_inner_solves = 0
    max_inner_stationarity = 0.0
    history = []
    status = "maxit"
    gap = residual = np.inf

    def predict(i):
        loss = parts[i]
        if method == "MC-LPALM":
            return u[i] - (loss.value_grad(u[i])[1] - lam[i]) / tau[i], 1, 0, 0.0
        # Ai embeds ui into constraint row i. The compressed image state
        # qi = Ai*u[i] + common has Ai.T*qi = u[i] + common[i].
        if method == "R2-PALM":
            center = u[i] + common[i] + lam[i] / beta
            coefficient = beta
        else:
            center = (z + lam[i] / beta + proximal_tau * u[i]) / (1 + proximal_tau)
            coefficient = beta * (1 + proximal_tau)

        def objective(v):
            value, grad = loss.value_grad(v)
            delta = v - center
            return value + 0.5 * coefficient * (delta @ delta), grad + coefficient * delta

        sol = minimize(objective, warm[i], jac=True, method="L-BFGS-B",
                       options={"maxiter": 200, "ftol": 0.0,
                                "gtol": inner_tol, "maxls": 50})
        stationarity = float(np.max(np.abs(sol.jac)))
        return sol.x, int(sol.nfev), int(sol.nit), stationarity

    for k in range(1, maxit + 1):
        ts = time.perf_counter()
        results = list(executor.map(predict, range(p))) if executor else [predict(i) for i in range(p)]
        ut = np.vstack([item[0] for item in results])
        gradients += sum(item[1] for item in results)
        inner_iterations += sum(item[2] for item in results)
        max_inner_stationarity = max(max_inner_stationarity, max(item[3] for item in results))
        failures = sum(item[3] > 10 * inner_tol for item in results)
        failed_inner_solves += failures
        if method == "MC-LPALM":
            zt = threshold(z - lam.sum(axis=0) / TAU_Z, reg / TAU_Z)
        elif method == "R2-PALM":
            zt = threshold(z - common.mean(axis=0) - lam.mean(axis=0) / beta,
                           reg / (beta * p))
            warm = ut.copy()
        else:
            zt = threshold(((u - lam / beta).mean(axis=0) + proximal_tau * z) /
                           (1 + proximal_tau), reg / (beta * p * (1 + proximal_tau)))
            warm = ut.copy()
        local_seconds += time.perf_counter() - ts
        if failures:
            status = "inner_failure"
            break
        if k % 5 == 0 or k == 1 or k == maxit:
            ts = time.perf_counter()
            value = full.value_grad(zt)[0] + reg * np.abs(zt).sum()
            gap = max(float(value - ref), 0.0)
            residual = float(np.linalg.norm(ut - zt, axis=1).max())
            diagnostics_seconds += time.perf_counter() - ts
            history.append(dict(round=k, seconds=time.perf_counter()-t0,
                                objective_gap=gap, consensus_residual=residual))
            if gap <= gap_tol and residual <= res_tol:
                status = "converged"
                break
        if k == maxit:
            break
        ts = time.perf_counter()
        if method == "MC-LPALM":
            du, dz = u - ut, z - zt
            rhs = u - z - du + dz
            base = invd[:, None] * rhs
            sl = base - invd[:, None] * base.sum(axis=0) / denom
            u -= alpha * (du + sl / tau[:, None])
            z -= alpha * (dz - sl.sum(axis=0) / TAU_Z)
            lam -= alpha * sl
        elif method == "R2-PALM":
            # There are p+1 primal blocks; hence the rank-two denominator p+2.
            # qi <- (1-alpha)qi + alpha*Ai*ut - alpha*r_tilde/(p+2).
            # Store qi = Ai*u[i] + common, qz = Az*z + common exactly.
            rt = ut - zt
            u = (1 - alpha) * u + alpha * ut
            z = (1 - alpha) * z + alpha * zt
            common = (1 - alpha) * common - alpha * rt / (p + 2)
            lam -= alpha * beta * rt / (p + 2)
        else:
            u, z = ut, zt
            lam -= beta * (ut - zt)
        correction_seconds += time.perf_counter() - ts
    if executor:
        executor.shutdown()
    total = time.perf_counter() - t0
    row = dict(method=method, alpha=alpha if method != "PJADMM" else np.nan,
               beta=beta, tau_z=TAU_Z if method == "MC-LPALM" else np.nan,
               tau_value=tau_value if method == "PJADMM" else np.nan, proximal_tau=proximal_tau,
               workers=workers, inner_tolerance=inner_tol, rounds=k, seconds=total,
               setup_seconds=setup, local_seconds=local_seconds,
               correction_seconds=correction_seconds, diagnostics_seconds=diagnostics_seconds,
               local_gradient_evaluations=gradients, inner_iterations=inner_iterations,
               max_inner_stationarity=max_inner_stationarity,
               failed_inner_solves=failed_inner_solves,
               objective_gap=gap, consensus_residual=residual, status=status,
               gap_tolerance=gap_tol, residual_tolerance=res_tol)
    return row, history


def append_csv(path, rows):
    pd.DataFrame(rows).to_csv(path, index=False)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mode", choices=["pilot", "tune", "final", "precision", "parallel", "inner"], required=True)
    parser.add_argument("--data-dir", type=Path, required=True)
    parser.add_argument("--out-dir", type=Path, required=True)
    parser.add_argument("--datasets", nargs="+", default=list(DATASETS))
    parser.add_argument("--p-values", nargs="+", type=int, default=[16, 32])
    parser.add_argument("--repetitions", type=int, default=5)
    parser.add_argument("--methods", nargs="+", choices=METHODS, default=list(METHODS))
    parser.add_argument("--selection-dataset", default=None,
                        help="Transfer each method's screened settings from this data set.")
    args = parser.parse_args()
    out = args.out_dir.resolve()
    out.mkdir(parents=True, exist_ok=True)
    environment = dict(python=platform.python_version(), platform=platform.platform(),
                       numpy=np.__version__, scipy=scipy.__version__, logical_cpus=os.cpu_count(),
                       alphas=ALPHAS, betas=BETAS, tau_z=TAU_Z,
                       pjadmm_proximal_values="0.501,1,2,0.75*(p+1)-1+0.001,p+0.001",
                       stopping_iterate="primal predictor", timing_scope="including solver setup",
                       blas_threads=1, inner_solver="warm-started L-BFGS-B")
    (out/"environment_r2.json").write_text(json.dumps(environment, indent=2))
    rows, histories = [], []
    with threadpool_limits(limits=1):
        for dataset in args.datasets:
            x, y, full, reg, ref = load_problem(dataset, args.data_dir, out)
            for p in args.p_values:
                parts = parts_for(x, y, p)
                if args.mode in ("pilot", "tune"):
                    grid = [(method, alpha, beta, np.nan)
                            for method in args.methods if method != "PJADMM"
                            for alpha, beta in itertools.product(ALPHAS, BETAS)]
                    if "PJADMM" in args.methods:
                        grid += [("PJADMM", 1.0, beta, factor)
                                 for beta, factor in itertools.product(BETAS, proximal_candidates(p))]
                    if args.mode == "pilot":
                        grid = [(m,a,b,f) for m,a,b,f in grid
                                if a in [1.0,1.5] and b in [0.025,0.1,0.5]
                                and (m!="PJADMM" or f in [0.501,1.0])]
                    np.random.default_rng(20260927 + p).shuffle(grid)
                    screen = []
                    suffix = "_" + "_".join(args.methods) if len(args.methods) < 3 else ""
                    for method, alpha, beta, factor in grid:
                        row, _ = run(method, parts, full, reg, ref, alpha, beta, maxit=3000,
                                     tau_value=factor)
                        row.update(dataset=dataset, p=p, phase="screen")
                        screen.append(row)
                        append_csv(out/f"{args.mode}_screen_{dataset}_p{p}{suffix}.csv", screen)
                        print("SCREEN", dataset, p, method, alpha, beta,
                              round(row["seconds"],3), row["rounds"], row["status"], flush=True)
                    if args.mode == "pilot":
                        continue
                    frame = pd.DataFrame(screen)
                    validation = []
                    for rep in range(1, 3):
                        order = args.methods if rep == 1 else args.methods[::-1]
                        for method in order:
                            top = frame[(frame.method == method) & (frame.status == "converged")].nsmallest(3, "seconds")
                            if top.empty:
                                raise RuntimeError(f"No converged candidates for {dataset} {p} {method}")
                            for _, candidate in top.iterrows():
                                row, _ = run(method, parts, full, reg, ref, candidate.alpha, candidate.beta,
                                             tau_value=candidate.tau_value)
                                row.update(dataset=dataset, p=p, phase="validation", repetition=rep)
                                validation.append(row)
                                append_csv(out/f"validation_{dataset}_p{p}{suffix}.csv", validation)
                    val = pd.DataFrame(validation)
                    med = val.groupby(["method","alpha","beta","tau_value"], as_index=False,
                                      dropna=False).agg(seconds=("seconds","median"),
                                                       all_converged=("status",lambda x:bool((x=="converged").all())))
                    med = med[med.all_converged]
                    chosen = med.sort_values("seconds").groupby("method", sort=False).head(1)
                    chosen_path=out/f"selected_{dataset}_p{p}.csv"
                    if chosen_path.exists():
                        previous=pd.read_csv(chosen_path)
                        chosen=pd.concat([previous[~previous.method.isin(args.methods)],chosen],ignore_index=True)
                    chosen.to_csv(chosen_path, index=False)
                    print("SELECTED", dataset, p, chosen.to_dict("records"), flush=True)
                    continue
                selection_dataset = args.selection_dataset or dataset
                selected = pd.read_csv(out/f"selected_{selection_dataset}_p{p}.csv").set_index("method")
                settings = [(5e-4, 1e-4, 1, 1e-8)]
                if args.mode == "precision":
                    settings = [(5e-4, 1e-4, 1, 1e-8), (1e-5, 1e-5, 1, 1e-8),
                                (1e-6, 1e-6, 1, 1e-8)]
                if args.mode == "parallel":
                    settings = [(5e-4, 1e-4, w, 1e-8) for w in [1,2,4]]
                if args.mode == "inner":
                    settings = [(5e-4, 1e-4, 1, t) for t in [1e-7,1e-9]]
                for gap_tol, res_tol, workers, inner_tol in settings:
                    for rep in range(1, args.repetitions+1):
                        shift=(rep-1)%len(args.methods)
                        order=args.methods[shift:]+args.methods[:shift]
                        for method in order:
                            params = selected.loc[method]
                            row, history = run(method, parts, full, reg, ref, params.alpha, params.beta,
                                               gap_tol, res_tol, workers=workers, inner_tol=inner_tol,
                                               tau_value=params.get("tau_value",np.nan))
                            row.update(dataset=dataset, p=p, repetition=rep,
                                       selection_dataset=selection_dataset)
                            rows.append(row)
                            append_csv(out/f"{args.mode}_raw.csv", rows)
                            for point in history:
                                point.update(dataset=dataset,p=p,method=method,repetition=rep,
                                             gap_tolerance=gap_tol,workers=workers,inner_tolerance=inner_tol)
                            histories.extend(history)
                            append_csv(out/f"{args.mode}_histories.csv", histories)
                            print("RUN",dataset,p,method,gap_tol,workers,inner_tol,rep,
                                  round(row["seconds"],3),row["rounds"],row["status"],flush=True)
    if rows:
        frame = pd.DataFrame(rows)
        keys = ["dataset","p","method","gap_tolerance","residual_tolerance","workers","inner_tolerance","alpha","beta","tau_value"]
        summary = frame.groupby(keys,as_index=False,dropna=False).agg(
            repetitions=("seconds","size"), median_seconds=("seconds","median"),
            q1_seconds=("seconds",lambda x:x.quantile(.25)), q3_seconds=("seconds",lambda x:x.quantile(.75)),
            median_rounds=("rounds","median"), median_gradients=("local_gradient_evaluations","median"),
            median_inner_iterations=("inner_iterations","median"),
            median_local_seconds=("local_seconds","median"),
            median_setup_seconds=("setup_seconds","median"),
            median_correction_seconds=("correction_seconds","median"),
            max_gap=("objective_gap","max"),max_residual=("consensus_residual","max"),
            max_inner_stationarity=("max_inner_stationarity","max"),
            inner_failures=("failed_inner_solves","sum"),
            all_converged=("status",lambda x:bool((x=="converged").all())))
        summary.to_csv(out/f"{args.mode}_summary.csv",index=False)
        print(summary.to_string(index=False),flush=True)


if __name__ == "__main__":
    lock_parser = argparse.ArgumentParser(add_help=False)
    lock_parser.add_argument("--out-dir", type=Path)
    lock_args, _ = lock_parser.parse_known_args()
    if lock_args.out_dir is None:
        main()
    else:
        with timing_lock(lock_args.out_dir.resolve()):
            main()
