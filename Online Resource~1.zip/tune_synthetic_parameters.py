"""Symmetric parameter screening for the synthetic exchange comparison."""
from __future__ import annotations

import itertools
import argparse
import json
import os
import sys
from pathlib import Path

for key in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ[key] = "1"

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
ESM = ROOT
sys.path.insert(0, str(ESM))
import reproduce_experiments as impl  # noqa: E402


def run(method: str, problem, params: dict):
    if method == "MC-LPALM":
        return impl.run_mc_exchange(problem, **params, tol=1e-6, maxit=20000)
    if method == "R2-PALM":
        return impl.run_r2_exchange(problem, **params, tol=1e-6, maxit=20000)
    return impl.run_pjadmm_exchange(problem, **params, tol=1e-6, maxit=20000)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out-dir", type=Path, default=ROOT / "tuning_synthetic")
    args = parser.parse_args()
    out = args.out_dir.resolve()
    out.mkdir(parents=True, exist_ok=True)
    alphas = (0.75, 1.0, 1.25, 1.5, 1.75)
    betas = (0.1, 0.2, 0.5, 1.0, 2.0)

    for p in (10, 20, 50, 100):
        problem = impl.generate_exchange_problem(p)
        candidates = []
        candidates.extend(("MC-LPALM", {"alpha": a, "beta": b})
                          for a, b in itertools.product(alphas, betas))
        candidates.extend(("R2-PALM", {"alpha": a, "beta": b})
                          for a, b in itertools.product(alphas, betas))
        candidates.extend(("PJADMM", {"tau": scale * (p - 1.0) + 1e-3, "beta": b})
                          for scale, b in itertools.product((0.1, 0.25, 0.5, 1.0, 2.0), betas))
        np.random.default_rng(2029 + p).shuffle(candidates)
        rows = []
        for idx, (method, params) in enumerate(candidates, 1):
            result = run(method, problem, params)
            row = {
                "p": p, "method": method, "parameters": json.dumps(params, sort_keys=True),
                "seconds": result.wall_seconds, "iterations": result.iterations,
                "objective": result.metric1, "feasibility": result.metric2,
                "status": result.status,
            }
            rows.append(row)
            if idx % 10 == 0 or idx == len(candidates):
                pd.DataFrame(rows).to_csv(out / f"screen_p{p}.csv", index=False)
                print(f"SCREEN p={p} {idx}/{len(candidates)} {row}", flush=True)

        frame = pd.DataFrame(rows)
        finals = []
        selected = {}
        for method in ("MC-LPALM", "R2-PALM", "PJADMM"):
            possible = frame[(frame.method == method) & (frame.status == "converged")]
            top = possible.nsmallest(2, "seconds").parameters.tolist()
            valid = []
            for param_string in top:
                params = json.loads(param_string)
                times = []
                for repetition in range(1, 6):
                    result = run(method, problem, params)
                    row = {
                        "p": p, "method": method, "parameters": param_string,
                        "repetition": repetition, "seconds": result.wall_seconds,
                        "iterations": result.iterations, "objective": result.metric1,
                        "feasibility": result.metric2, "status": result.status,
                    }
                    finals.append(row)
                    times.append(result.wall_seconds)
                valid.append((float(np.median(times)), param_string))
            selected[method] = min(valid)[1]
            pd.DataFrame(finals).to_csv(out / f"validation_p{p}.csv", index=False)
        print(f"SELECTED p={p}: " + json.dumps(selected, sort_keys=True), flush=True)

    raw = pd.concat([pd.read_csv(out / f"validation_p{p}.csv") for p in (10, 20, 50, 100)])
    raw.to_csv(out / "validation_all.csv", index=False)
    summary = raw.groupby(["p", "method", "parameters"], as_index=False).agg(
        repetitions=("seconds", "size"), median_seconds=("seconds", "median"),
        q1_seconds=("seconds", lambda v: v.quantile(0.25)),
        q3_seconds=("seconds", lambda v: v.quantile(0.75)),
        median_iterations=("iterations", "median"),
        all_converged=("status", lambda v: bool((v == "converged").all())),
    )
    summary.to_csv(out / "validation_summary.csv", index=False)
    print(summary.to_string(index=False))


if __name__ == "__main__":
    main()
