#!/usr/bin/env python3
"""Create Figs. 5--7 from the archived or recomputed CSV files."""
from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch

mpl.rcParams["pdf.fonttype"] = 42
mpl.rcParams["ps.fonttype"] = 42


def save_vector(fig: plt.Figure, out_dir: Path, stem: str) -> None:
    fig.savefig(out_dir / f"{stem}.pdf", bbox_inches="tight")
    fig.savefig(out_dir / f"{stem}.eps", bbox_inches="tight")
    plt.close(fig)


def make_workflow(out_dir: Path) -> None:
    fig, ax = plt.subplots(figsize=(8.0, 2.4))
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.axis("off")
    boxes = [
        (0.03, 0.29, 0.25, 0.46, "Data / variable\nblocks"),
        (0.37, 0.23, 0.28, 0.58, "Parallel local\npredictors"),
        (0.73, 0.29, 0.24, 0.46, "Metric-compatible\ncorrection"),
    ]
    for x, y, width, height, label in boxes:
        patch = FancyBboxPatch(
            (x, y),
            width,
            height,
            boxstyle="round,pad=0.012,rounding_size=0.018",
            linewidth=1.2,
            facecolor="white",
            edgecolor="black",
        )
        ax.add_patch(patch)
        ax.text(x + width / 2, y + height / 2, label, ha="center", va="center", fontsize=12)
    for start, end in [((0.28, 0.52), (0.37, 0.52)), ((0.65, 0.52), (0.73, 0.52))]:
        ax.add_patch(FancyArrowPatch(start, end, arrowstyle="-|>", mutation_scale=13, linewidth=1.1))
    ax.text(
        0.5,
        0.08,
        "Shared-memory threads or independent worker processes",
        ha="center",
        va="center",
        fontsize=10.5,
    )
    save_vector(fig, out_dir, "Fig5")


def make_scaling(out_dir: Path, csv_path: Path) -> None:
    frame = pd.read_csv(csv_path)
    fig, axes = plt.subplots(1, 2, figsize=(8.0, 3.4))
    markers = {"threads": "o", "processes": "s"}
    labels = {"threads": "Threads", "processes": "Processes"}
    linestyles = {"threads": "-", "processes": "--"}
    for backend, group in frame.groupby("backend", sort=False):
        group = group.sort_values("workers")
        axes[0].plot(
            group["workers"],
            group["speedup"],
            marker=markers.get(backend, "o"),
            linestyle=linestyles.get(backend, "-"),
            label=labels.get(backend, backend),
        )
        axes[1].plot(
            group["workers"],
            group["efficiency"],
            marker=markers.get(backend, "o"),
            linestyle=linestyles.get(backend, "-"),
            label=labels.get(backend, backend),
        )
    max_workers = int(frame["workers"].max())
    ideal_workers = np.array(sorted(frame["workers"].unique()))
    axes[0].plot(ideal_workers, ideal_workers, linestyle=":", label="Ideal")
    axes[0].set_title("(a) Strong-scaling speedup")
    axes[0].set_xlabel("Workers")
    axes[0].set_ylabel("Speedup")
    axes[0].set_xticks(ideal_workers)
    axes[0].set_xlim(0.85, max_workers + 0.15)
    axes[0].legend(frameon=False)
    axes[1].set_title("(b) Parallel efficiency")
    axes[1].set_xlabel("Workers")
    axes[1].set_ylabel("Parallel efficiency")
    axes[1].set_xticks(ideal_workers)
    axes[1].set_xlim(0.85, max_workers + 0.15)
    axes[1].set_ylim(0.0, 1.05)
    axes[1].legend(frameon=False)
    for ax in axes:
        ax.grid(True, linestyle=":", linewidth=0.6)
    fig.tight_layout()
    save_vector(fig, out_dir, "Fig6")


def make_sensitivity(out_dir: Path, csv_path: Path) -> None:
    frame = pd.read_csv(csv_path)
    alpha_rows = frame[frame["vary"] == "alpha"].sort_values("alpha")
    beta_rows = frame[frame["vary"] == "beta"].sort_values("beta")
    fig, axes = plt.subplots(1, 2, figsize=(8.0, 3.4))
    axes[0].plot(alpha_rows["alpha"], alpha_rows["iterations"], marker="o")
    axes[0].set_title(r"(a) Sensitivity to $\alpha$")
    axes[0].set_xlabel(r"Relaxation $\alpha$")
    axes[0].set_ylabel("Iterations")
    axes[1].semilogx(beta_rows["beta"], beta_rows["feasibility"], marker="s")
    axes[1].set_title(r"(b) Sensitivity to $\beta$")
    axes[1].set_xlabel(r"Penalty $\beta$")
    axes[1].set_ylabel("Final feasibility")
    for ax in axes:
        ax.grid(True, linestyle=":", linewidth=0.6)
    fig.tight_layout()
    save_vector(fig, out_dir, "Fig7")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-dir", type=Path, default=Path("."))
    parser.add_argument("--out-dir", type=Path, default=Path("."))
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    args.out_dir.mkdir(parents=True, exist_ok=True)
    scaling = args.data_dir / "parallel_scaling_results.csv"
    sensitivity = args.data_dir / "sensitivity_results.csv"
    if not scaling.exists():
        raise FileNotFoundError(scaling)
    if not sensitivity.exists():
        raise FileNotFoundError(sensitivity)
    make_workflow(args.out_dir)
    make_scaling(args.out_dir, scaling)
    make_sensitivity(args.out_dir, sensitivity)
    print(f"Wrote Fig5--Fig7 to {args.out_dir}")


if __name__ == "__main__":
    main()
