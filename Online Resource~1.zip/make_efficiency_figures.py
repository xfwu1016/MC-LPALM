"""Create evidence-focused figures from the archived experiment summaries.

Inputs are kept beside this script so the submitted PDF/EPS figures can be
reproduced without changing or smoothing the measured data.
"""
from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.lines import Line2D


COLORS = {
    "MC-LPALM": "#1f77b4",
    "L-ADMM": "#ff7f0e",
    "QN-ADMM": "#2ca02c",
    "PJADMM": "#d62728",
    "R2-PALM": "#9467bd",
}

plt.rcParams.update({
    "font.size": 9,
    "axes.labelsize": 9,
    "axes.titlesize": 10,
    "legend.fontsize": 8,
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
})


def save_vector(fig, out_dir: Path, stem: str) -> None:
    fig.savefig(out_dir / f"{stem}.pdf", bbox_inches="tight")
    fig.savefig(out_dir / f"{stem}.eps", bbox_inches="tight")
    fig.savefig(out_dir / f"{stem}.png", dpi=220, bbox_inches="tight")
    plt.close(fig)


def make_synthetic_ratio(data_path: Path, out_dir: Path) -> None:
    raw = pd.read_csv(data_path)
    med = raw.groupby(["p", "method"], as_index=False).agg(
        seconds=("seconds", "median"), status=("status", lambda x: x.iloc[0]))
    mc = med[med.method == "MC-LPALM"].set_index("p")

    fig, ax = plt.subplots(figsize=(6.4, 4.15))
    methods = ["PJADMM", "R2-PALM"]
    markers = {"PJADMM": "s", "R2-PALM": "^"}
    for method in methods:
        grp = med[med.method == method].sort_values("p").copy()
        grp["ratio"] = [
            float(row.seconds / mc.loc[row.p, "seconds"])
            for row in grp.itertuples()
        ]
        converged = grp.status == "converged"
        ax.plot(grp.loc[converged, "p"], grp.loc[converged, "ratio"],
                marker=markers[method], linewidth=1.7, markersize=5,
                color=COLORS[method], label=f"{method} / MC-LPALM")
        # A nonconverged capped run is retained as an open marker and identified
        # explicitly; its ratio is an observed cap-time ratio, not a speedup to
        # the common tolerance.
        capped = grp.loc[~converged]
        if not capped.empty:
            ax.scatter(capped.p, capped.ratio, marker=markers[method], s=48,
                       facecolors="white", edgecolors=COLORS[method],
                       linewidths=1.5, zorder=4)
            for row in capped.itertuples():
                ax.annotate("PJADMM hit 20,000-update cap\nwithout meeting tolerance",
                            xy=(row.p, row.ratio), xytext=(57, 24),
                            textcoords="data", arrowprops={"arrowstyle": "->", "lw": 0.8},
                            ha="left", va="top", fontsize=7, color=COLORS[method])

    ax.axhline(1.0, color="black", linestyle="--", linewidth=1.0)
    ax.set_yscale("log")
    ax.set_ylim(0.03, 30)
    ax.set_xticks(sorted(mc.index.to_list()))
    ax.set_xlabel("Number of blocks $p$")
    ax.set_ylabel("Baseline / MC-LPALM median time\n(above 1 favors MC-LPALM)")
    ax.grid(True, which="both", linestyle=":", linewidth=0.6, alpha=0.7)
    ax.legend(loc="upper left", frameon=True)
    fig.tight_layout()
    save_vector(fig, out_dir, "Fig2")


def _median_trajectory(history: pd.DataFrame, method: str) -> pd.DataFrame:
    subset = history[history.method == method]
    return subset.groupby("iterations", as_index=False).agg(
        wall_seconds=("wall_seconds", "median"),
        objective_gap=("objective_gap", "median"),
        consensus_residual=("consensus_residual", "median"))


def make_a9a_history(history_path: Path, out_dir: Path) -> None:
    history = pd.read_csv(history_path)
    methods = ["MC-LPALM", "L-ADMM", "QN-ADMM"]
    fig, axes = plt.subplots(1, 2, figsize=(8.0, 3.55), sharex=True)
    y_specs = [
        ("objective_gap", 5e-4, "Objective gap"),
        ("consensus_residual", 1e-4, "Consensus residual"),
    ]
    for ax, (field, threshold, label) in zip(axes, y_specs):
        for method in methods:
            curve = _median_trajectory(history, method)
            values = np.maximum(curve[field].to_numpy(dtype=float), 1e-12)
            ax.semilogy(curve.wall_seconds, values, marker="o", markersize=2.4,
                        linewidth=1.5, markevery=max(1, len(curve) // 12),
                        color=COLORS[method], label=method)
            end = curve.iloc[-1]
            ax.scatter([end.wall_seconds], [max(float(end[field]), 1e-12)],
                       color=COLORS[method], marker="D", s=24, zorder=5)
        ax.axhline(threshold, color="black", linestyle="--", linewidth=1.0)
        ax.set_xlabel("Wall-clock time (s)")
        ax.set_ylabel(label)
        ax.grid(True, which="both", linestyle=":", linewidth=0.6, alpha=0.7)
    axes[0].set_title("(a) Objective accuracy")
    axes[1].set_title("(b) Consensus feasibility")
    handles = [Line2D([0], [0], color=COLORS[method], marker="o", linewidth=1.5,
                      markersize=4, label=method)
               for method in methods]
    handles.extend([
        Line2D([0], [0], color="black", linestyle="--", linewidth=1.0,
               label="Objective-gap tolerance $5\\times10^{-4}$"),
        Line2D([0], [0], color="black", linestyle="--", linewidth=1.0,
               label="Consensus tolerance $10^{-4}$"),
    ])
    fig.legend(handles=handles, loc="upper center", ncol=3,
               bbox_to_anchor=(0.5, 1.04), frameon=False)
    fig.tight_layout(rect=(0, 0, 1, 0.92))
    save_vector(fig, out_dir, "Fig3")


def _profile_times(frame: pd.DataFrame, ax, title: str) -> None:
    methods = ["MC-LPALM", "L-ADMM", "QN-ADMM"]
    times = frame[methods].to_numpy(dtype=float)
    if not np.isfinite(times).all() or (times <= 0).any():
        raise ValueError(f"Invalid timing data in performance profile: {title}")
    ratios = times / times.min(axis=1, keepdims=True)
    tau_max = float(ratios.max())
    tau = np.geomspace(1.0, max(1.05, tau_max * 1.05), 400)
    for j, method in enumerate(methods):
        profile = (ratios[:, j, None] <= tau[None, :]).mean(axis=0)
        ax.step(tau, profile, where="post", color=COLORS[method],
                linewidth=1.8, label=method)
    ax.axvline(1.0, color="black", linestyle=":", linewidth=0.8)
    ax.set_xscale("log")
    ax.set_xlim(1.0, max(1.05, tau_max * 1.05))
    if tau_max < 2.0:
        ticks = [x for x in (1.0, 1.2, 1.4, 1.6, 1.8) if x <= tau_max * 1.05]
    else:
        ticks = [x for x in (1.0, 2.0, 4.0, 8.0, 12.0) if x <= tau_max * 1.05]
    ax.set_xticks(ticks, labels=[f"{x:g}" for x in ticks])
    ax.minorticks_off()
    ax.set_ylim(-0.02, 1.02)
    ax.set_yticks(np.linspace(0, 1, 6))
    ax.set_title(title)
    ax.set_xlabel("Runtime ratio to the fastest method, $\\tau$")
    ax.grid(True, which="major", linestyle=":", linewidth=0.6, alpha=0.7)


def make_logistic_performance_profiles(cross_path: Path, a9a_path: Path,
                                       out_dir: Path) -> None:
    cross = pd.read_csv(cross_path)
    cross_times = pd.DataFrame({
        "dataset": cross.dataset,
        "p": cross.p,
        "MC-LPALM": cross["MC-LPALM_median_seconds"],
        "L-ADMM": cross["L-ADMM_median_seconds"],
        "QN-ADMM": cross["QN-ADMM_median_seconds"],
    })
    a9a = pd.read_csv(a9a_path)
    a9a = a9a.pivot(index="p", columns="method", values="median_seconds").reset_index()
    fig, axes = plt.subplots(1, 2, figsize=(8.3, 3.65), sharey=True)
    _profile_times(cross_times, axes[0],
                   "(a) Four data sets, p=16,32\nFixed parameters; 8 configurations")
    _profile_times(a9a, axes[1],
                   "(b) a9a, p=4,8,16,32,64\nParameter screening; 5 configurations")
    axes[0].set_ylabel("Fraction of configurations within $\\tau$ of best")
    handles = [Line2D([0], [0], color=COLORS[method], linewidth=1.8,
                      label=method)
               for method in ("MC-LPALM", "L-ADMM", "QN-ADMM")]
    fig.legend(handles=handles, loc="upper center", ncol=3,
               bbox_to_anchor=(0.5, 1.04), frameon=False)
    fig.tight_layout(rect=(0, 0, 1, 0.91))
    save_vector(fig, out_dir, "Fig4")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    script_dir = Path(__file__).resolve().parent
    parser.add_argument("--data-dir", type=Path, default=script_dir)
    parser.add_argument("--out-dir", type=Path, default=script_dir)
    args = parser.parse_args()
    args.out_dir.mkdir(parents=True, exist_ok=True)
    make_synthetic_ratio(args.data_dir / "synthetic_fair_tuned_summary.csv", args.out_dir)
    make_a9a_history(args.data_dir / "a9a_p8_history_equal_budget.csv", args.out_dir)
    make_logistic_performance_profiles(
        args.data_dir / "cross_dataset_summary.csv",
        args.data_dir / "a9a_fair_tuned_summary.csv",
        args.out_dir)


if __name__ == "__main__":
    main()
