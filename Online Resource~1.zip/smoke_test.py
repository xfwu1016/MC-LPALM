#!/usr/bin/env python3
"""Fast deterministic checks for the supplied MC-LPALM implementation."""
from __future__ import annotations

import numpy as np

import reproduce_experiments as rep
import reproduce_parallel_scaling as scaling


def main() -> None:
    assert np.allclose(rep.soft_threshold(np.array([-2.0, -0.2, 0.3, 2.0]), 0.5), [-1.5, 0.0, 0.0, 1.5])

    problem = rep.generate_exchange_problem(4, seed=20260726)
    initial_obj, initial_feas = rep.exchange_metrics(problem, np.zeros((4, 50)))
    result = rep.run_mc_exchange(problem, alpha=1.5, beta=1.0, tol=1e-5, maxit=5000)
    assert result.status == "converged", result
    assert result.metric1 < initial_obj
    assert result.metric2 <= 1e-5

    b, c, tau = scaling.generate_problem(p=4, ell=80, n=30, seed=1234, power_iterations=8)
    row = scaling.one_run(b, c, tau, workers=1, backend="threads", iterations=5)
    assert np.isfinite(float(row["merit"]))
    assert float(row["iteration_seconds"]) > 0.0

    print("All smoke tests passed.")


if __name__ == "__main__":
    main()
