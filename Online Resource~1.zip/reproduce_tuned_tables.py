"""Regenerate the manuscript's tuned-result summaries from archived runs."""
from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd


def summarize(frame: pd.DataFrame, group_fields: list[str],
              time_field: str, iteration_field: str,
              metric_fields: list[str]) -> pd.DataFrame:
    aggregations = {
        "repetitions": (time_field, "size"),
        "median_seconds": (time_field, "median"),
        "q1_seconds": (time_field, lambda values: values.quantile(0.25)),
        "q3_seconds": (time_field, lambda values: values.quantile(0.75)),
        "median_iterations": (iteration_field, "median"),
        "all_converged": ("status", lambda values: bool((values == "converged").all())),
    }
    for metric in metric_fields:
        aggregations[f"median_{metric}"] = (metric, "median")
    return frame.groupby(group_fields, as_index=False).agg(**aggregations)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-dir", type=Path, default=Path("."))
    parser.add_argument("--out-dir", type=Path, default=Path("recomputed"))
    args = parser.parse_args()
    args.out_dir.mkdir(parents=True, exist_ok=True)

    synthetic = pd.read_csv(args.data_dir / "synthetic_fair_tuned_final_10_runs.csv")
    synthetic_summary = summarize(
        synthetic, ["p", "method", "parameters"], "seconds", "iterations",
        ["objective", "feasibility"])
    synthetic_summary["seconds"] = synthetic_summary["median_seconds"]
    synthetic_summary["status"] = "converged"
    synthetic_summary.to_csv(args.out_dir / "synthetic_fair_tuned_summary.csv", index=False)

    a9a = pd.read_csv(args.data_dir / "a9a_fair_tuned_final_10_runs.csv")
    a9a_summary = summarize(
        a9a, ["p", "method", "parameters"], "seconds", "iterations",
        ["gap", "residual"])
    a9a_summary.to_csv(args.out_dir / "a9a_fair_tuned_summary.csv", index=False)
    print("Wrote tuned-result summaries to", args.out_dir)


if __name__ == "__main__":
    main()
