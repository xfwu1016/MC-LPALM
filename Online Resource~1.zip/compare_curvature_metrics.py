"""MC-LPALM curvature-matrix ablation with unchanged screened parameters.

The logistic data blocks have no nonsmooth local term. A fixed positive
definite matrix therefore preserves an explicit gradient predictor.
The shared regularizer still uses scalar-metric soft thresholding.
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from compare_r2_logistic import (
    load_problem, parts_for, threshold, timing_lock, TAU_Z,
)
import numpy as np
import pandas as pd
from scipy.linalg import cho_factor, cho_solve
from threadpoolctl import threadpool_limits

METHOD = "MC-LPALM-curvature"
RIDGE_FACTOR = 1e-3


def run_curvature(parts, full, reg, ref, alpha, beta, gap_tol, res_tol,
                  workers=1, inner_tol=1e-8, maxit=20000):
    p, d = len(parts), full.x.shape[1]
    start = time.perf_counter()
    u, z, lam = np.zeros((p, d)), np.zeros(d), np.zeros((p, d))
    executor = ThreadPoolExecutor(max_workers=workers) if workers > 1 else None
    inverses, dual_blocks, conditions, slacks = [], [], [], []
    for loss in parts:
        gram = (loss.xt @ loss.x).toarray() / (4 * loss.denominator)
        gram = 0.5 * (gram + gram.T)
        ell = float(np.abs(gram).sum(axis=1).max())
        eig, vectors = np.linalg.eigh(gram)
        # Clipping tiny negative roundoff gives a PSD upper approximation.
        eig = np.maximum(eig, 0.0)
        ridge = RIDGE_FACTOR * ell + 1e-8
        values = 1.10 * eig / (2 - alpha) + ridge
        inverse = (vectors / values[None, :]) @ vectors.T
        dual = (vectors * (beta * values / (beta + values))[None, :]) @ vectors.T
        inverses.append(0.5 * (inverse + inverse.T))
        dual_blocks.append(0.5 * (dual + dual.T))
        conditions.append(float(values.max() / values.min()))
        slacks.append(float(((2 - alpha) * values - eig).min()))
    inverses, dual_blocks = np.asarray(inverses), np.asarray(dual_blocks)
    aggregate = cho_factor(TAU_Z * np.eye(d) + dual_blocks.sum(axis=0),
                           lower=True, check_finite=False)
    setup = time.perf_counter() - start
    local_seconds = correction_seconds = diagnostics_seconds = 0.0
    history = []
    status, gap, residual = "maxit", np.inf, np.inf

    def predict(i):
        return u[i] - inverses[i] @ (parts[i].value_grad(u[i])[1] - lam[i])

    for k in range(1, maxit + 1):
        tick = time.perf_counter()
        predictions = list(executor.map(predict, range(p))) if executor else [
            predict(i) for i in range(p)]
        ut = np.vstack(predictions)
        zt = threshold(z - lam.sum(axis=0) / TAU_Z, reg / TAU_Z)
        local_seconds += time.perf_counter() - tick
        if k == 1 or k % 5 == 0 or k == maxit:
            tick = time.perf_counter()
            value = full.value_grad(zt)[0] + reg * np.abs(zt).sum()
            gap = max(float(value - ref), 0.0)
            residual = float(np.linalg.norm(ut - zt, axis=1).max())
            diagnostics_seconds += time.perf_counter() - tick
            history.append(dict(round=k, seconds=time.perf_counter()-start,
                                objective_gap=gap, consensus_residual=residual))
            if gap <= gap_tol and residual <= res_tol:
                status = "converged"
                break
        if k == maxit:
            break
        tick = time.perf_counter()
        du, dz = u - ut, z - zt
        base = np.einsum("ijk,ik->ij", dual_blocks, ut - zt, optimize=True)
        shared = cho_solve(aggregate, base.sum(axis=0), check_finite=False)
        sl = base - np.einsum("ijk,k->ij", dual_blocks, shared, optimize=True)
        u -= alpha * (du + np.einsum("ijk,ik->ij", inverses, sl, optimize=True))
        z -= alpha * (dz - sl.sum(axis=0) / TAU_Z)
        lam -= alpha * sl
        correction_seconds += time.perf_counter() - tick
    if executor:
        executor.shutdown()
    row = dict(method=METHOD, metric="curvature matrix", alpha=float(alpha),
               beta=float(beta), tau_z=TAU_Z, tau_value=np.nan,
               ridge_factor=RIDGE_FACTOR, max_metric_condition=max(conditions),
               minimum_metric_slack=min(slacks), workers=workers,
               inner_tolerance=inner_tol, rounds=k, seconds=time.perf_counter()-start,
               setup_seconds=setup, local_seconds=local_seconds,
               correction_seconds=correction_seconds,
               diagnostics_seconds=diagnostics_seconds,
               local_gradient_evaluations=p*k, inner_iterations=0,
               max_inner_stationarity=0.0, failed_inner_solves=0,
               objective_gap=gap, consensus_residual=residual, status=status,
               gap_tolerance=gap_tol, residual_tolerance=res_tol)
    return row, history


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-dir", type=Path, required=True)
    parser.add_argument("--out-dir", type=Path, required=True)
    parser.add_argument("--mode", choices=["all", "precision", "parallel", "inner"],
                        default="all")
    parser.add_argument("--datasets", nargs="+", default=["a9a"])
    parser.add_argument("--p-values", nargs="+", type=int, default=[16, 32])
    parser.add_argument("--repetitions", type=int, default=3)
    parser.add_argument("--wait-for-precision", action="store_true",
                        help="Wait for the baseline precision archive before running.")
    args = parser.parse_args()
    out = args.out_dir.resolve()
    # Wait before acquiring the lock so a fresh baseline driver can also
    # use the lock without a circular wait.
    if args.wait_for_precision:
        print("WAITING_FOR_BASELINE_PRECISION", flush=True)
        while not (out / "precision_summary.csv").exists():
            time.sleep(1)
    with timing_lock(out):
        metadata = dict(method=METHOD, ridge_factor=RIDGE_FACTOR,
                        ridge_floor=1e-8, curvature_multiplier=1.10,
                        parameters="unchanged from scalar MC-LPALM selection",
                        max_prediction_rounds=20000, additional_parameter_screening=False,
                        stopping_iterate="primal predictor", blas_threads=1,
                        correction="block diagonal plus rank-d Woodbury")
        (out / "environment_curvature.json").write_text(json.dumps(metadata, indent=2))
        modes = ["precision", "parallel", "inner"] if args.mode == "all" else [args.mode]
        with threadpool_limits(limits=1):
            for mode in modes:
                print("CURVATURE_STAGE_START", mode, flush=True)
                rows, histories = [], []
                for dataset in args.datasets:
                    x, y, full, reg, ref = load_problem(dataset, args.data_dir, out)
                    for p in args.p_values:
                        if mode in ("parallel", "inner") and p != 32:
                            continue
                        parts = parts_for(x, y, p)
                        params = pd.read_csv(out / f"selected_a9a_p{p}.csv").set_index(
                            "method").loc["MC-LPALM"]
                        settings = [(5e-4, 1e-4, 1, 1e-8),
                                    (1e-5, 1e-5, 1, 1e-8),
                                    (1e-6, 1e-6, 1, 1e-8)]
                        if mode == "parallel":
                            settings = [(5e-4, 1e-4, w, 1e-8) for w in [1, 2, 4]]
                        elif mode == "inner":
                            settings = [(5e-4, 1e-4, 1, t) for t in [1e-7, 1e-9]]
                        for gap_tol, res_tol, workers, inner_tol in settings:
                            for rep in range(1, args.repetitions + 1):
                                row, trace = run_curvature(
                                    parts, full, reg, ref, params.alpha, params.beta,
                                    gap_tol, res_tol, workers, inner_tol)
                                row.update(dataset=dataset, p=p, repetition=rep,
                                           selection_dataset="a9a")
                                rows.append(row)
                                pd.DataFrame(rows).to_csv(
                                    out / f"curvature_{mode}_raw.csv", index=False)
                                for point in trace:
                                    point.update(dataset=dataset, p=p, method=METHOD,
                                                 repetition=rep, gap_tolerance=gap_tol,
                                                 workers=workers, inner_tolerance=inner_tol)
                                histories.extend(trace)
                                pd.DataFrame(histories).to_csv(
                                    out / f"curvature_{mode}_histories.csv", index=False)
                                print("CURVATURE_RUN", dataset, p, gap_tol, workers, rep,
                                      round(row["seconds"], 3), row["rounds"],
                                      row["status"], flush=True)
                frame = pd.DataFrame(rows)
                keys = ["dataset", "p", "method", "gap_tolerance", "residual_tolerance",
                        "workers", "inner_tolerance", "alpha", "beta", "tau_value"]
                summary = frame.groupby(keys, as_index=False, dropna=False).agg(
                    repetitions=("seconds", "size"), median_seconds=("seconds", "median"),
                    q1_seconds=("seconds", lambda s:s.quantile(.25)),
                    q3_seconds=("seconds", lambda s:s.quantile(.75)),
                    median_rounds=("rounds", "median"),
                    median_gradients=("local_gradient_evaluations", "median"),
                    median_inner_iterations=("inner_iterations", "median"),
                    median_local_seconds=("local_seconds", "median"),
                    median_setup_seconds=("setup_seconds", "median"),
                    median_correction_seconds=("correction_seconds", "median"),
                    max_gap=("objective_gap", "max"),
                    max_residual=("consensus_residual", "max"),
                    max_inner_stationarity=("max_inner_stationarity", "max"),
                    inner_failures=("failed_inner_solves", "sum"),
                    minimum_metric_slack=("minimum_metric_slack", "min"),
                    max_metric_condition=("max_metric_condition", "max"),
                    all_converged=("status", lambda s:bool((s=="converged").all())))
                summary.to_csv(out / f"curvature_{mode}_summary.csv", index=False)
                print("CURVATURE_STAGE_COMPLETE", mode, flush=True)
        print("ALL_CURVATURE_EXPERIMENTS_COMPLETE", flush=True)


if __name__ == "__main__":
    main()
