"""Build the direct R2-PALM/PJADMM table, statistics, and Fig8 from archives."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

mpl.rcParams.update({"pdf.fonttype":42, "ps.fonttype":42, "font.size":10.5,
                     "axes.labelsize":10.5, "legend.fontsize":10})
METHODS = ["MC-LPALM","R2-PALM","PJADMM"]
PLOT_METHODS = ["MC-LPALM-curvature"] + METHODS
COLORS = {"MC-LPALM-curvature":"#0066AA","MC-LPALM":"#666666",
          "R2-PALM":"#D45A00","PJADMM":"#228833"}
MARKERS = {"MC-LPALM-curvature":"o","MC-LPALM":"D","R2-PALM":"s","PJADMM":"^"}
LABELS = {"MC-LPALM-curvature":"MC-LPALM (matrix)","MC-LPALM":"MC-LPALM (scalar)",
          "R2-PALM":"R2-PALM","PJADMM":"PJADMM"}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-dir",type=Path,default=Path("."))
    parser.add_argument("--out-dir",type=Path,default=Path("recomputed"))
    args=parser.parse_args()
    source=args.data_dir.resolve()
    if (source/"r2_direct").is_dir():
        source=source/"r2_direct"
    out=args.out_dir.resolve()
    out.mkdir(parents=True,exist_ok=True)
    final=pd.read_csv(source/"final_summary.csv")
    precision=pd.read_csv(source/"precision_summary.csv")
    parallel=pd.read_csv(source/"parallel_summary.csv")
    precision=pd.concat([precision,pd.read_csv(source/"curvature_precision_summary.csv")],
                        ignore_index=True)
    parallel=pd.concat([parallel,pd.read_csv(source/"curvature_parallel_summary.csv")],
                       ignore_index=True)
    rows=[]
    speeds=[]
    pj_speeds=[]
    work_ratios=[]
    pj_work_ratios=[]
    local_fractions=[]
    for dataset in ["a9a","phishing","w8a","ijcnn1"]:
        for p in [16,32]:
            group=final[(final.dataset==dataset)&(final.p==p)].set_index("method")
            mc,r2,pj=group.loc[METHODS[0]],group.loc[METHODS[1]],group.loc[METHODS[2]]
            if not all(bool(item.all_converged) for item in [mc,r2,pj]):
                raise RuntimeError(f"Nonconvergence must be reported explicitly: {dataset} {p}")
            ratio=r2.median_seconds/mc.median_seconds
            speeds.append(float(ratio))
            pj_ratio=pj.median_seconds/mc.median_seconds
            pj_speeds.append(float(pj_ratio))
            work_ratios.append(float(r2.median_gradients/mc.median_gradients))
            pj_work_ratios.append(float(pj.median_gradients/mc.median_gradients))
            local_fractions.append(float(r2.median_local_seconds/r2.median_seconds))
            times=[float(item.median_seconds) for item in [mc,r2,pj]]
            best=min(times)
            cells=[r"\textbf{"+f"{value:.3f}"+"}" if value==best else f"{value:.3f}"
                   for value in times]
            rows.append(f"{dataset} & {p} & "+" & ".join(cells)
                        +f" & {ratio:.2f} & {pj_ratio:.2f}"+r"\\")
    table=r"""\begin{table}[H]
\caption{Direct sparse-logistic comparison with R2-PALM and PJADMM. MC-LPALM uses scalar block metrics. Parameters are selected on a9a and transferred to the other data sets. Times include solver setup and are medians of three fresh serial runs. All methods satisfy the same predictor-based objective-gap and consensus tolerances, $5\cdot10^{-4}$ and $10^{-4}$. The smallest time in each row is bold.}\label{tab:r2-logistic}
\centering
\small
\setlength{\tabcolsep}{4pt}
\begin{tabular}{lr r r r r r}
\toprule
 & & \multicolumn{3}{c}{Time (s)} & \multicolumn{2}{c}{Runtime ratio}\\
\cmidrule(lr){3-5}\cmidrule(lr){6-7}
Data set & $p$ & \MC & \RTP & \PJ & $T_{\mathrm{R2}}/T_{\mathrm{MC}}$ & $T_{\mathrm{PJ}}/T_{\mathrm{MC}}$\\
\midrule
"""
    table+="\n".join(rows)
    table+="\n"+r"""\bottomrule
\end{tabular}
\end{table}
"""
    (out/"r2_logistic_table.tex").write_text(table,encoding="utf-8")
    fig,axes=plt.subplots(2,2,figsize=(5.8,5.6))
    for column,p_value in enumerate([16,32]):
        ax=axes[0,column]
        for method in PLOT_METHODS:
            g=precision[(precision.dataset=="a9a")&(precision.method==method)&(precision.p==p_value)].sort_values("gap_tolerance",ascending=False)
            reached=g[g.all_converged]
            missed=g[~g.all_converged]
            ax.errorbar(reached.gap_tolerance,reached.median_seconds,
                        yerr=np.vstack([reached.median_seconds-reached.q1_seconds,
                                        reached.q3_seconds-reached.median_seconds]),
                        color=COLORS[method],marker=MARKERS[method],capsize=3,
                        label=LABELS[method],linewidth=1.4,
                        linestyle="--" if method=="MC-LPALM" else "-")
            for _,point in missed.iterrows():
                ax.scatter(point.gap_tolerance,point.median_seconds,marker="x",
                           color=COLORS[method],s=42)
                note="limit" if point.median_rounds>=20000 else "not reached"
                ax.annotate(note,(point.gap_tolerance,point.median_seconds),
                            xytext=(-12,-20),textcoords="offset points",ha="right",fontsize=9)
        ax.set_xscale("log")
        ax.set_yscale("log")
        ax.invert_xaxis()
        ax.set_xlabel("Objective-gap tolerance")
        ax.set_ylabel("Total time (s)")
        ax.set_title(f"({'ab'[column]}) a9a: accuracy, p = {p_value}")
        ax.grid(True,which="major",color="#DDDDDD")
        ax=axes[1,column]
        for method in PLOT_METHODS:
            if column==0:
                g=parallel[(parallel.dataset=="a9a")&(parallel.method==method)&(parallel.p==32)].sort_values("workers")
                if not g.all_converged.all():
                    raise RuntimeError(f"Nonconverged parallel curve: a9a {method}")
                ax.errorbar(g.workers,g.median_seconds,
                            yerr=np.vstack([g.median_seconds-g.q1_seconds,g.q3_seconds-g.median_seconds]),
                            color=COLORS[method],marker=MARKERS[method],capsize=3,
                            label=LABELS[method],linewidth=1.4,
                            linestyle="--" if method=="MC-LPALM" else "-")
            else:
                g=precision[(precision.dataset=="a9a")&(precision.method==method)&(precision.p==32)].sort_values("gap_tolerance",ascending=False)
                reached=g[g.all_converged]
                missed=g[~g.all_converged]
                ax.plot(reached.gap_tolerance,reached.median_gradients,
                        color=COLORS[method],marker=MARKERS[method],
                        label=LABELS[method],linewidth=1.4,
                        linestyle="--" if method=="MC-LPALM" else "-")
                ax.scatter(missed.gap_tolerance,missed.median_gradients,
                           marker="x",color=COLORS[method],s=42)
        ax.set_yscale("log")
        if column==0:
            ax.set_xticks([1,2,4])
            ax.set_xlabel("Concurrent thread workers")
            ax.set_ylabel("Total time (s)")
            ax.set_title("(c) a9a: workers, p = 32")
        else:
            ax.set_xscale("log")
            ax.invert_xaxis()
            ax.set_xlabel("Objective-gap tolerance")
            ax.set_ylabel("Local gradient evaluations")
            ax.set_title("(d) a9a: local work, p = 32")
        ax.grid(True,which="major",color="#DDDDDD")
    handles,labels=axes[0,0].get_legend_handles_labels()
    fig.legend(handles,labels,loc="upper center",bbox_to_anchor=(0.5,0.995),
               ncol=2,frameon=False,columnspacing=1.0)
    fig.tight_layout(pad=1.2,rect=[0,0,1,0.875])
    for suffix in ["pdf","eps","png"]:
        fig.savefig(out/f"Fig8.{suffix}",dpi=200)
    plt.close(fig)
    precision_ratios=[]
    for (dataset,p,tol),g in precision.groupby(["dataset","p","gap_tolerance"]):
        s=g.set_index("method")
        scalar_ok=bool(s.loc["MC-LPALM","all_converged"])
        matrix_ok=bool(s.loc["MC-LPALM-curvature","all_converged"])
        r2_ok=bool(s.loc["R2-PALM","all_converged"])
        pj_ok=bool(s.loc["PJADMM","all_converged"])
        precision_ratios.append(dict(dataset=dataset,p=int(p),gap_tolerance=float(tol),
                                     scalar_converged=scalar_ok,matrix_converged=matrix_ok,
                                     r2_converged=r2_ok,pj_converged=pj_ok,
                                     speedup_r2=float(s.loc["R2-PALM","median_seconds"]/s.loc["MC-LPALM","median_seconds"]) if scalar_ok and r2_ok else None,
                                     speedup_pj=float(s.loc["PJADMM","median_seconds"]/s.loc["MC-LPALM","median_seconds"]) if scalar_ok and pj_ok else None,
                                     matrix_speedup_r2=float(s.loc["R2-PALM","median_seconds"]/s.loc["MC-LPALM-curvature","median_seconds"]) if matrix_ok and r2_ok else None,
                                     matrix_speedup_pj=float(s.loc["PJADMM","median_seconds"]/s.loc["MC-LPALM-curvature","median_seconds"]) if matrix_ok and pj_ok else None))
    parallel_ratios=[]
    for (dataset,workers),g in parallel.groupby(["dataset","workers"]):
        s=g.set_index("method")
        parallel_ratios.append(dict(dataset=dataset,workers=int(workers),
                                    speedup_r2=float(s.loc["R2-PALM","median_seconds"]/s.loc["MC-LPALM","median_seconds"]),
                                    speedup_pj=float(s.loc["PJADMM","median_seconds"]/s.loc["MC-LPALM","median_seconds"]),
                                    matrix_speedup_r2=float(s.loc["R2-PALM","median_seconds"]/s.loc["MC-LPALM-curvature","median_seconds"]),
                                    matrix_speedup_pj=float(s.loc["PJADMM","median_seconds"]/s.loc["MC-LPALM-curvature","median_seconds"])))
    stats=dict(final_speedup_min=min(speeds),final_speedup_max=max(speeds),
               final_geometric_speedup=float(np.exp(np.log(speeds).mean())),
               final_pj_speedup_min=min(pj_speeds),final_pj_speedup_max=max(pj_speeds),
               final_pj_geometric_speedup=float(np.exp(np.log(pj_speeds).mean())),
               gradient_ratio_min=min(work_ratios),gradient_ratio_max=max(work_ratios),
               pj_gradient_ratio_min=min(pj_work_ratios),pj_gradient_ratio_max=max(pj_work_ratios),
               r2_local_fraction_min=min(local_fractions),r2_local_fraction_max=max(local_fractions),
               final_all_converged=bool(final.all_converged.all()),
               final_max_inner_stationarity=float(final.max_inner_stationarity.max()),
               final_max_gap=float(final.max_gap.max()),
               final_max_consensus=float(final.max_residual.max()),
               curvature_all_precision_converged=bool(precision[precision.method=="MC-LPALM-curvature"].all_converged.all()),
               scalar_unreached_precision_targets=precision[(precision.method=="MC-LPALM")&(~precision.all_converged)][["dataset","p","gap_tolerance","median_rounds"]].to_dict("records"),
               precision_ratios=precision_ratios,parallel_ratios=parallel_ratios)
    (out/"r2_direct_statistics.json").write_text(json.dumps(stats,indent=2))
    print(json.dumps(stats,indent=2))


if __name__=="__main__":
    main()
