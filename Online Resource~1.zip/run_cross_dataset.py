"""Repeated sparse-logistic consensus benchmarks on public LIBSVM datasets.

The same MC-LPALM, L-ADMM, and QN-ADMM implementations and stopping criteria
are used for all data sets. Data loading and reference-objective calculation
are outside the solver timers; method-specific metric construction remains
inside each solver timer, as in the manuscript's original experiment.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
from pathlib import Path

# Match the manuscript environment and prevent nested BLAS parallelism.
for _name in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ[_name] = "1"

import numpy as np
import pandas as pd
from sklearn.datasets import load_svmlight_file

_HERE = Path(__file__).resolve().parent
CODE_DIR = _HERE if (_HERE / "reproduce_experiments.py").exists() else _HERE.parent / "esm1_revised"
sys.path.insert(0, str(CODE_DIR))
import reproduce_experiments as impl  # noqa: E402


DATASETS = {
    "a9a": ("a9a", 123),
    "phishing": ("phishing", 68),
    "w8a": ("w8a", 300),
    "ijcnn1": ("ijcnn1.bz2", 22),
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def load_scaled(path: Path, n_features: int):
    x, y = load_svmlight_file(str(path), n_features=n_features, zero_based="auto")
    x = x.tocsr().astype(np.float64)
    y = np.where(y > 0, 1.0, -1.0)
    n = x.shape[0]
    col_sq = np.asarray(x.power(2).sum(axis=0)).ravel()
    scale = np.ones_like(col_sq)
    nz = col_sq > 0
    scale[nz] = np.sqrt(n / col_sq[nz])
    return x.multiply(scale).tocsr(), y


def benchmark_dataset(name: str, data_dir: Path, out_dir: Path,
                      p_values: list[int], repetitions: int,
                      maxit: int, reference_maxit: int,
                      reference_tol: float) -> tuple[pd.DataFrame, pd.DataFrame]:
    filename, n_features = DATASETS[name]
    path = data_dir / filename
    if not path.is_file():
        raise FileNotFoundError(f"Missing {name} file: {path}")

    x, y = load_scaled(path, n_features)
    n, d = x.shape
    _, grad0 = impl.logistic_value_grad(x, y, np.zeros(d), n)
    lambda_max = float(np.max(np.abs(grad0)))
    reg = 0.05 * lambda_max
    print(f"REFERENCE_START {name}: n={n}, d={d}, tol={reference_tol:g}, "
          f"maxit={reference_maxit}", flush=True)
    _, ref_obj, lips = impl.fista_reference(
        x, y, reg, maxit=reference_maxit, tol=reference_tol)
    data_hash = sha256(path)
    print(f"DATASET {name}: n={n}, d={d}, nnz={x.nnz}, reg={reg:.9g}, "
          f"reference={ref_obj:.12g}, lips={lips:.9g}, sha256={data_hash}", flush=True)

    raw_rows: list[dict[str, object]] = []
    for p in p_values:
        parts = impl.partition_rows(x, y, p)
        method_factories = {
            "MC-LPALM": lambda: impl.run_mc_consensus(
                parts, x, y, reg, ref_obj, alpha=1.5, beta=0.2, tau_z=0.25,
                maxit=maxit, gap_tol=5e-4, res_tol=1e-4),
            "L-ADMM": lambda: impl.run_linearized_admm(
                parts, x, y, reg, ref_obj, rho=0.2, maxit=maxit,
                gap_tol=5e-4, res_tol=1e-4),
            "QN-ADMM": lambda: impl.run_exact_admm(
                parts, x, y, reg, ref_obj, rho=0.2, maxit=maxit,
                gap_tol=5e-4, res_tol=1e-4),
        }
        method_names = list(method_factories)
        for rep in range(1, repetitions + 1):
            # Rotate order to avoid always timing one method first.
            shift = (rep - 1) % len(method_names)
            order = method_names[shift:] + method_names[:shift]
            for method in order:
                result = method_factories[method]()
                row = {
                    "dataset": name,
                    "n": n,
                    "d": d,
                    "nnz": int(x.nnz),
                    "dataset_sha256": data_hash,
                    "p": p,
                    "method": method,
                    "repetition": rep,
                    "iterations": result.iterations,
                    "wall_seconds": result.wall_seconds,
                    "objective_gap": result.metric1,
                    "consensus_residual": result.metric2,
                    "training_accuracy": getattr(result, "accuracy", np.nan),
                    "nonzeros": getattr(result, "nonzeros", np.nan),
                    "status": result.status,
                    "reference_objective": ref_obj,
                    "lambda": reg,
                    "alpha": 1.5,
                    "beta_or_rho": 0.2,
                }
                raw_rows.append(row)
                print("RUN " + json.dumps(row, sort_keys=True), flush=True)
                # Keep a recoverable checkpoint after every completed run.
                pd.DataFrame(raw_rows).to_csv(out_dir / f"{name}_raw.csv", index=False)

    raw = pd.DataFrame(raw_rows)
    summary_rows: list[dict[str, object]] = []
    for p in p_values:
        group = raw[raw.p == p]
        per_method: dict[str, dict[str, object]] = {}
        for method in method_names:
            values = group[group.method == method]
            times = values.wall_seconds.to_numpy(dtype=float)
            per_method[method] = {
                "median_seconds": float(np.median(times)),
                "q1_seconds": float(np.quantile(times, 0.25)),
                "q3_seconds": float(np.quantile(times, 0.75)),
                "median_iterations": float(np.median(values.iterations)),
                "all_converged": bool((values.status == "converged").all()),
                "max_objective_gap": float(values.objective_gap.max()),
                "max_consensus_residual": float(values.consensus_residual.max()),
            }
        mc = per_method["MC-LPALM"]["median_seconds"]
        row: dict[str, object] = {
            "dataset": name, "n": n, "d": d, "nnz": int(x.nnz), "p": p,
            "repetitions": repetitions, "dataset_sha256": data_hash,
        }
        for method, stats in per_method.items():
            for stat, value in stats.items():
                row[f"{method}_{stat}"] = value
        for baseline in ("L-ADMM", "QN-ADMM"):
            row[f"speedup_MC_vs_{baseline}"] = (
                per_method[baseline]["median_seconds"] / mc
            )
        summary_rows.append(row)

    summary = pd.DataFrame(summary_rows)
    summary.to_csv(out_dir / f"{name}_summary.csv", index=False)
    return raw, summary


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-dir", type=Path, default=Path(__file__).parent / "data")
    parser.add_argument("--out-dir", type=Path, default=Path(__file__).parent / "results")
    parser.add_argument("--datasets", nargs="+", choices=DATASETS, default=list(DATASETS))
    parser.add_argument("--p-values", nargs="+", type=int, default=[4, 8, 16])
    parser.add_argument("--repetitions", type=int, default=5)
    parser.add_argument("--maxit", type=int, default=3000)
    parser.add_argument("--reference-maxit", type=int, default=20000)
    parser.add_argument("--reference-tol", type=float, default=1e-8)
    args = parser.parse_args()
    if args.repetitions < 3:
        parser.error("Use at least three repetitions for the reported timing medians.")
    args.out_dir.mkdir(parents=True, exist_ok=True)

    all_raw, all_summary = [], []
    for name in args.datasets:
        raw, summary = benchmark_dataset(
            name, args.data_dir, args.out_dir, args.p_values,
            args.repetitions, args.maxit, args.reference_maxit,
            args.reference_tol)
        all_raw.append(raw)
        all_summary.append(summary)
        pd.concat(all_raw, ignore_index=True).to_csv(
            args.out_dir / "cross_dataset_raw.csv", index=False)
        pd.concat(all_summary, ignore_index=True).to_csv(
            args.out_dir / "cross_dataset_summary.csv", index=False)


if __name__ == "__main__":
    main()
