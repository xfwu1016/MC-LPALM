#!/usr/bin/env python3
"""Reproduce the relaxation- and penalty-sensitivity experiment."""
from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd

import reproduce_experiments as rep


def run_sensitivity(
    out_dir: Path,
    p: int = 50,
    tolerance: float = 1e-6,
    max_iterations: int = 30000,
) -> pd.DataFrame:
    problem = rep.generate_exchange_problem(p)
    rows: list[dict[str, object]] = []

    for alpha in [0.5, 1.0, 1.2, 1.5, 1.8]:
        result = rep.run_mc_exchange(
            problem,
            alpha=alpha,
            beta=1.0,
            tol=tolerance,
            maxit=max_iterations,
        )
        rows.append(
            {
                "vary": "alpha",
                "alpha": alpha,
                "beta": 1.0,
                "iterations": result.iterations,
                "wall_seconds": result.wall_seconds,
                "objective": result.metric1,
                "feasibility": result.metric2,
                "status": result.status,
            }
        )

    for beta in [0.2, 0.5, 1.0, 2.0, 5.0]:
        result = rep.run_mc_exchange(
            problem,
            alpha=1.5,
            beta=beta,
            tol=tolerance,
            maxit=max_iterations,
        )
        rows.append(
            {
                "vary": "beta",
                "alpha": 1.5,
                "beta": beta,
                "iterations": result.iterations,
                "wall_seconds": result.wall_seconds,
                "objective": result.metric1,
                "feasibility": result.metric2,
                "status": result.status,
            }
        )

    frame = pd.DataFrame(rows)
    out_dir.mkdir(parents=True, exist_ok=True)
    output = out_dir / "sensitivity_results.csv"
    frame.to_csv(output, index=False)
    print(frame.to_string(index=False))
    print(f"Wrote {output}")
    return frame


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out-dir", type=Path, default=Path("."))
    parser.add_argument("--blocks", type=int, default=50)
    parser.add_argument("--tolerance", type=float, default=1e-6)
    parser.add_argument("--max-iterations", type=int, default=30000)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    run_sensitivity(
        out_dir=args.out_dir,
        p=args.blocks,
        tolerance=args.tolerance,
        max_iterations=args.max_iterations,
    )


if __name__ == "__main__":
    main()
