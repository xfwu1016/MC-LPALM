"""Rebuild the nine manuscript figures and summary artifacts from archives."""
from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path


def run(script: Path, data_dir: Path, out_dir: Path) -> None:
    command = [sys.executable, str(script), "--data-dir", str(data_dir),
               "--out-dir", str(out_dir)]
    print("+", " ".join(command), flush=True)
    subprocess.run(command, check=True)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-dir", type=Path, default=Path("."))
    parser.add_argument("--out-dir", type=Path, default=Path("recomputed"))
    args = parser.parse_args()
    here = Path(__file__).resolve().parent
    data_dir = args.data_dir.resolve()
    out_dir = args.out_dir.resolve()
    out_dir.mkdir(parents=True, exist_ok=True)

    run(here / "reproduce_tuned_tables.py", data_dir, out_dir)
    run(here / "make_synthetic_history_figure.py", data_dir, out_dir)
    run(here / "make_efficiency_figures.py", data_dir, out_dir)
    run(here / "make_parallel_figures.py", data_dir, out_dir)
    run(here / "make_r2_figures.py", data_dir, out_dir)
    run(here / "make_li_figures.py", data_dir, out_dir)
    print(f"Recreated all nine figures and archived-data summaries in {out_dir}")


if __name__ == "__main__":
    main()
