"""Rebuild Table 8, Figure 9 and Li2025 comparison statistics from raw runs."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib as mpl
import matplotlib.pyplot as plt
from compare_li_logistic import summary

METHODS = ['MC-LPALM','MC-LPALM-curvature','Li2025-fixed','Li2025-adaptive']
LABELS = {'MC-LPALM':'MC-LPALM (scalar)','MC-LPALM-curvature':'MC-LPALM (matrix)',
          'Li2025-fixed':'Li2025 (Alg. 2)','Li2025-adaptive':'Li2025 (Alg. 1)'}
COLORS = dict(zip(METHODS,['#666666','#0066AA','#228833','#D45A00']))
MARKERS = dict(zip(METHODS,['D','o','^','s']))
LINESTYLES = dict(zip(METHODS,['-','-','--','-.']))
mpl.rcParams.update({'pdf.fonttype':42,'ps.fonttype':42,'font.size':10,
                     'axes.labelsize':10,'legend.fontsize':9.5})

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data-dir',type=Path,default=Path('.'))
    parser.add_argument('--out-dir',type=Path,default=Path('recomputed'))
    args = parser.parse_args()
    source = args.data_dir.resolve()
    if (source/'li_direct').is_dir():
        source = source/'li_direct'
    out = args.out_dir.resolve()
    out.mkdir(parents=True,exist_ok=True)
    for phase in ['final','precision','inner']:
        rows = pd.read_csv(source/f'{phase}_raw.csv').to_dict('records')
        summary(out/f'li_{phase}_summary.csv',rows)
    final = pd.read_csv(out/'li_final_summary.csv')
    precision = pd.read_csv(out/'li_precision_summary.csv')
    rows, ratios = [], []
    for dataset in ['a9a','phishing','w8a','ijcnn1']:
        for p in [16,32]:
            g = final[(final.dataset==dataset)&(final.p==p)].set_index('method')
            reached = g[g.all_converged]
            best = reached.median_seconds.min() if len(reached) else np.nan
            cells = []
            for method in METHODS:
                v = g.loc[method]
                cell = f'{v.median_seconds:.3f}'
                if not v.all_converged:
                    cell += r'$^{\dagger}$'
                elif v.median_seconds==best:
                    cell = r'\textbf{'+cell+'}'
                cells.append(cell)
            rows.append(f'{dataset} & {p} & '+' & '.join(cells)+r'\\')
            item = dict(dataset=dataset,p=p,fastest_method=reached.median_seconds.idxmin() if len(reached) else None)
            for mc in METHODS[:2]:
                for li in METHODS[2:]:
                    key = f'{li}/{mc}'
                    item[key] = float(g.loc[li,'median_seconds']/g.loc[mc,'median_seconds']) if g.loc[li,'all_converged'] and g.loc[mc,'all_converged'] else None
            ratios.append(item)
    table = r'''\begin{table}[H]
\caption{Direct comparison with Li et al.\ \cite{li2025balanced}. Times (s) are medians of three fresh serial runs at predictor-based objective-gap and consensus targets $5\cdot10^{-4}$ and $10^{-4}$. Li-A2 and Li-A1 denote their fixed-factor Algorithm~2 and adaptive-factor Algorithm~1. MC-S and MC-M use scalar and curvature-matrix metrics. All parameter selection is performed on a9a. The smallest successful time per row is bold; a dagger denotes a target not reached in all three runs.}\label{tab:li-logistic}
\centering
\small
\setlength{\tabcolsep}{6pt}
\begin{tabular}{lr rrrr}
\toprule
Data set & $p$ & MC-S & MC-M & Li-A2 & Li-A1\\
\midrule
'''+ '\n'.join(rows) + '\n' + r'''\bottomrule
\end{tabular}
\end{table}
'''
    (out/'li_logistic_table.tex').write_text(table,encoding='utf-8')
    fig,axes = plt.subplots(2,2,figsize=(5.8,5.5))
    for column,p in enumerate([16,32]):
        for method in METHODS:
            g = precision[(precision.p==p)&(precision.method==method)].sort_values('gap_tolerance',ascending=False)
            good, bad = g[g.all_converged],g[~g.all_converged]
            axes[0,column].errorbar(good.gap_tolerance,good.median_seconds,
                yerr=np.vstack([good.median_seconds-good.q1_seconds,good.q3_seconds-good.median_seconds]),
                marker=MARKERS[method],color=COLORS[method],label=LABELS[method],
                linestyle=LINESTYLES[method],capsize=3,linewidth=1.3)
            axes[1,column].plot(good.gap_tolerance,good.median_gradients,
                marker=MARKERS[method],color=COLORS[method],
                linestyle=LINESTYLES[method],linewidth=1.3)
            for ax,value in [(axes[0,column],'median_seconds'),(axes[1,column],'median_gradients')]:
                ax.scatter(bad.gap_tolerance,bad[value],marker='x',color=COLORS[method],s=45)
        for row in [0,1]:
            ax = axes[row,column]
            ax.set_xscale('log'); ax.set_yscale('log'); ax.invert_xaxis()
            ax.set_xlabel('Objective-gap tolerance')
            ax.grid(True,which='major',color='#DDDDDD')
            ax.set_title(f"({'abcd'[row*2+column]}) a9a: p = {p}")
        axes[0,column].set_ylabel('Total time (s)')
        axes[1,column].set_ylabel('Local gradient evaluations')
    handles,labels = axes[0,0].get_legend_handles_labels()
    fig.legend(handles,labels,loc='upper center',bbox_to_anchor=(.5,.995),ncol=2,frameon=False)
    fig.tight_layout(pad=1.2,rect=[0,0,1,.875])
    for ext in ['pdf','eps','png']:
        fig.savefig(out/f'Fig9.{ext}',dpi=220)
    plt.close(fig)
    stats = dict(configurations=ratios,final_successes=int(pd.read_csv(source/'final_raw.csv').status.eq('converged').sum()),
                 precision_successes=int(pd.read_csv(source/'precision_raw.csv').status.eq('converged').sum()),
                 final_runs=len(pd.read_csv(source/'final_raw.csv')),precision_runs=len(pd.read_csv(source/'precision_raw.csv')))
    inner = pd.read_csv(source/'inner_raw.csv')
    stats.update(inner_runs=len(inner),inner_successes=int(inner.status.eq('converged').sum()))
    for mc in METHODS[:2]:
        for li in METHODS[2:]:
            key = f'{li}/{mc}'
            values = [v[key] for v in ratios if v[key] is not None]
            stats[key] = dict(successful_pairs=len(values),wins=int(sum(v>1 for v in values)),
                              geometric_mean_ratio=float(np.exp(np.log(values).mean())) if values else None)
    (out/'li_statistics.json').write_text(json.dumps(stats,indent=2))
    print(json.dumps(stats,indent=2))

if __name__=='__main__':
    main()
