# Li2025 comparison protocol

## Sources and implementation

Li, Xu, Zhang (2025), DOI 10.1007/s10915-025-02935-9, Algorithms 1 and 2, equations (17), (19)-(21). The inconsistent printed Algorithm 3 is not used. The objective, partitioning, feature scaling, zero initialization, independent reference solutions and predictor stopping diagnostics match the archived R2-PALM/PJADMM study.

Both Li implementations solve the full local logistic proximal objective using warm-started L-BFGS-B, maxiter=200, ftol=0, gtol=1e-8, maxls=50. A stationarity residual greater than 1e-7 flags a failed inner solve. The shared L1 proximal mapping is exact soft thresholding. The scalar r applies to all p+1 primal blocks, including the shared variable.

The consensus Schur inverse is evaluated analytically using diagonal-plus-rank-one structure. No dense pd-by-pd matrix is formed. For eta=0, the old residual is cached with d_next=(1-rho)*d+rho*q; this applies to both the fixed and adaptive variants. For other eta values, separate right-hand sides are evaluated at prediction and correction. All operation counts are archived.

## Predeclared 35-candidate grids

At each of p=16,32, each Li family evaluates 35 configurations on a9a. Let i=0,...,6 and j=0,...,4:

- r_i is a seven-point geometric grid from 0.001 to 1.
- s_i is a seven-point geometric grid from 0.01 to 100.
- eta_j = {-1,-0.5,0,0.5,1}.
- candidate (i,j) uses r_i, s_((i+2j) mod 7), eta_j.
- Algorithm 2 fixes rho=1.
- Algorithm 1 uses gamma_((i+j) mod 4), with gamma={1,1.3,1.6,1.9}; its adaptive quotient is recomputed each iteration.

Each r and s appears five times, each eta appears seven times. This is a predefined coverage design with a 35-evaluation budget, not the full Cartesian product. Its broad valid parameter range is not restricted to slow baseline settings. The random execution order is deterministic and interleaves both Li families. All outcomes are retained.

Screening has a 3000-round cap, matching the earlier MC-LPALM screen. The three fastest converged candidates in each family are each validated twice, and the lowest validation median selects the setting. Equal candidate counts do not mean equal tuning CPU time or a guaranteed global optimum. The selected parameters are transferred unchanged to the other data sets and to tighter targets.

MC-LPALM uses its settings from the preceding 35-candidate a9a screen (same p values). The curvature-matrix variant uses these same alpha/beta values with its previously specified metric formula and receives no additional search. Fresh timings of both MC implementations are obtained alongside Li methods in this new comparison; earlier reported wall times are not mixed into the new table.

## Final comparisons

- final: a9a, phishing, w8a and ijcnn1; p=16,32; three fresh serial runs per method/configuration (96 runs).
- precision: a9a; p=16,32; target pairs (5e-4,1e-4), (1e-5,1e-5), (1e-6,1e-6); three fresh runs per method/target (72 runs).
- inner: a9a at p=32 and the standard outer targets; local tolerances 1e-6 and 1e-8; three fresh runs of all four implementations (24 runs). This supplementary check was specified before final timing data were produced. The selected algorithm parameters remain unchanged, and the MC gradient predictors are unaffected by the local-solver tolerance.
- The final cap is 20000 rounds. Stopping is assessed at round 1 and then every five rounds, on primal predictors, at the same objective-gap/consensus pair for all methods.
- Run order rotates across repetitions. Internal BLAS uses one thread. The timing lock serializes all tuning and final stages. No concurrent benchmark processes execute numerical stages.

Total solver time includes algorithm-specific setup, local optimizers/gradient evaluations, dual prediction, correction, adaptive-factor work and common stopping diagnostics. Loading, partitioning, independent reference calculation and tuning are excluded. Curvature-matrix setup is included. Nonconverged runs are retained and marked; their times are censored, and they are not used as successful time-to-target speedups.

## Reproduction

Use compare_li_logistic.py with --mode tune/final/precision, --data-dir, --out-dir, and --mc-archive pointing to the archived R2 study (reference metadata and MC selections). The source LIBSVM files are obtained separately. make_li_figures.py rebuilds summaries, Table 8, Figure 9 and statistics from the raw records, without rerunning timing experiments.

The theoretically equivalent nonsmooth scalar-metric unit-relaxation case is discussed separately in Section 4.5. The present experiments use smooth logistic blocks and compare full proximal versus explicit gradient operations; they do not present two affinely identical nonsmooth iterations as distinct algorithms.

## Recorded timing interruption

See PRECISION_TIMING_REPAIR.md and precision_initial_*.csv. Full affected groups were retimed with unchanged settings after an overnight computer suspension.
