# Online Resource 1: Reproducibility package

**Article:** A metric-compatible linearized relaxed parallel augmented Lagrangian method for composite convex learning  
**Target journal:** Journal of Scientific Computing  
**Authors:** Xiaofei Wu and Sheng Fu

This resource contains the experiment code, archived timing records, parameter-screening logs, and figure scripts. The files in the archive reproduce the reported summaries and figures without rerunning timing experiments. Timing can vary across hardware and software environments.

**Public implementation repository:** https://github.com/xfwu1016/MC-LPALM

This archive accompanies the revised manuscript and includes the extended R2-PALM/PJADMM, curvature-matrix, and Li2025 studies. Use this complete archive to reproduce the current tables and figures.

## Algorithmic context

For fixed metrics and parameters, the revised manuscript identifies MC-LPALM as a block-metric realization of relaxed Davis-Yin three-operator splitting through an affine change of variables. In the purely nonsmooth case with a common scalar metric and unit relaxation, it also establishes an exact affine correspondence with Algorithm 2 of Li, Xu and Zhang (2025) at zero extrapolation. The new Li comparison therefore uses the smooth composite logistic model, where complete proximal minimization and the gradient predictor differ. The implementation uses the original primal-dual variables, concurrent local predictions, and a fixed constraint-space correction. The preceding theoretical clarification does not change the earlier solver implementations, screened parameters, archived numerical outputs, or figure data in this resource.

## Rebuild tables and figures from the archived records

Install the pinned packages and run:

```bash
python -m pip install -r requirements-lock.txt
python reproduce_all.py --data-dir . --out-dir ./recomputed
```

This regenerates the tuned-result and direct-comparison summaries and Figures 1--9. Figure 4 is an empirical performance profile: for each configuration, runtime is divided by the fastest method's runtime for that same configuration.

## Repeat parameter tuning

The archived records include the parameter-screening and validation results used in the paper. To rerun the searches, use:

```bash
python tune_synthetic_parameters.py --out-dir ./tuning_synthetic
python finalize_synthetic_tuned.py
python tune_a9a_equal_budget.py --a9a-path ./a9a --out-dir ./tuning_a9a_equal_budget --p-values 4 8 16 32 64
```

The synthetic search evaluates 25 configurations per method, validates the two leading configurations in five runs, and times the selected configuration in ten additional runs. For a9a, MC-LPALM and each ADMM baseline screen seven configurations at each of five partition counts ($p=4,8,16,32,64$), validate the three leading candidates in three runs, and time the selected configuration in ten fresh runs. All methods use the same initialization, objective-gap and consensus tolerances, and outer-iteration limit. Screening and validation times are not included in the reported solver times. The a9a data file is not redistributed; obtain the training file from LIBSVM and place it at `./a9a`, or pass another path with `--a9a-path`.

## Archived records

- `synthetic_fair_tuned_final_10_runs.csv` and `synthetic_fair_tuned_summary.csv`: final ten-run synthetic timings and summaries.
- `parameter_screening/synthetic/`: 25-candidate screens, finalist validation runs, and candidate summaries.
- `a9a_fair_tuned_final_10_runs.csv` and `a9a_fair_tuned_summary.csv`: final ten-run a9a timings and summaries.
- `parameter_screening/a9a/`: equal-budget screens, finalist validation runs, and summaries for $p=4,8,16,32,64$.
- `a9a_mc_parameter_grid.csv`: the seven MC-LPALM parameter triples used in the equal-budget a9a screen.
- `a9a_p8_history_equal_budget.csv` and `synthetic_p50_equal_budget_history.csv`: trajectories used in Figures 3 and 1.
- `cross_dataset_raw.csv` and `cross_dataset_summary.csv`: three serial runs for each of eight data-set/partition configurations and their summaries.
- `parallel_scaling_results.csv` and `sensitivity_results.csv`: records used in Figures 6 and 7.
- `make_efficiency_figures.py`, `make_synthetic_history_figure.py`, and `make_parallel_figures.py`: figure-generation scripts.
- `reproduce_experiments.py`, `run_cross_dataset.py`, `reproduce_parallel_scaling.py`, and `reproduce_sensitivity.py`: solver implementations and experiment drivers.

The four data sets in the cross-dataset study are a9a, phishing, w8a, and ijcnn1. Their SHA-256 identifiers are recorded in `cross_dataset_raw.csv`. The source data are public LIBSVM files and are not redistributed here.

## Reproducibility notes

- Internal BLAS threading was fixed to one for the archived comparisons.
- The cross-dataset logistic study uses common fixed algorithm parameters and is separate from the equal-budget a9a tuning study.
- Iteration counts and stopping diagnostics are more portable than wall-clock times. Runtime depends on hardware, numerical libraries, system load, and operating-system scheduling.
- The parallel measurements are from one host and do not establish multi-node scaling.


## Direct comparison with corrected and proximal parallel methods

`compare_r2_logistic.py` implements MC-LPALM, the original image-space R2-PALM iteration, and PJADMM for the same sparse-logistic consensus objective. The R2-PALM image states are compressed algebraically to linear storage in the number of partitions; the correction is not projected. R2-PALM and PJADMM both use warm-started local L-BFGS-B solves with recorded stationarity residuals, gradient evaluations, and inner iteration counts. PJADMM includes small proximal coefficients allowed by the consensus matrix condition, as well as generic block-count-based coefficients.

At p = 16 and 32, each method screens 35 configurations on a9a, validates its three leading converged candidates twice, and transfers its selected setting unchanged to the other three data sets. The new direct comparison is evaluated at primal predictors for all methods; the preceding ADMM study is evaluated at corrected/current primal iterates. Its times therefore form a separate internally consistent comparison. All final times include algorithm-specific setup, local solves, correction, diagnostics, and (for threaded runs) worker setup and dispatch. Screening, loading, and reference calculation are excluded. The independent reference solution has a reported stationarity residual below 1e-9.

Archived records are in `r2_direct/`: complete screening and validation CSVs, selected settings, reference-solution metadata and source-data checksums, raw repeated timings and trajectories, summary CSVs, and an environment record. `final_*` covers all four data sets at the standard tolerances. `precision_*` compares three accuracy targets on a9a at p = 16 and 32. `parallel_*` compares one, two, and four thread workers on a9a at p = 32. `inner_*` reports sensitivity to the local solver tolerance. The CPU backend is shared-memory threading on one host; these records are not cluster timings.

To regenerate the additional table and figure from the archive:

```bash
python make_r2_figures.py --data-dir . --out-dir ./recomputed
```

To repeat the direct experiments (place the four original LIBSVM files in `./data`):

```bash
python compare_r2_logistic.py --mode tune --data-dir ./data --out-dir ./r2_recomputed --datasets a9a --p-values 16 32
python compare_r2_logistic.py --mode final --data-dir ./data --out-dir ./r2_recomputed --selection-dataset a9a --repetitions 3
python compare_r2_logistic.py --mode precision --data-dir ./data --out-dir ./r2_recomputed --datasets a9a --p-values 16 32 --selection-dataset a9a --repetitions 3
python compare_r2_logistic.py --mode parallel --data-dir ./data --out-dir ./r2_recomputed --datasets a9a --p-values 32 --selection-dataset a9a --repetitions 3
python compare_r2_logistic.py --mode inner --data-dir ./data --out-dir ./r2_recomputed --datasets a9a --p-values 32 --selection-dataset a9a --repetitions 3
```

The plots are generated from the raw numerical output of these implementations. The archived full precision and timing results are retained regardless of which method has the smallest runtime.

## Curvature-matrix metric ablation

Figure 8 also evaluates MC-LPALM with full local curvature-matrix metrics on a9a. This variant uses the same selected alpha, beta and shared scalar metric as the scalar version; no additional parameter grid is screened. The fixed ridge is 0.001 times the local curvature row-sum bound plus 1e-8. The predictors still use one gradient per local block. A block-diagonal-plus-rank-d Schur formula reuses one d-by-d Cholesky factor. Every timing includes construction of the dense matrix operators and the correction factorization.

The additional driver is compare_curvature_metrics.py. Its raw runs, trajectories and summaries use the curvature_precision_*, curvature_parallel_* and curvature_inner_* file prefixes in r2_direct/. Matrix condition numbers and positive metric-slack eigenvalues are recorded. The dense operators require O(p*d^2) storage.

After the baseline experiments above, repeat this metric ablation with:

    python compare_curvature_metrics.py --mode all --data-dir ./data --out-dir ./r2_recomputed --repetitions 3

Both metric variants remain in the archive and in the accuracy figure. Crosses denote targets not reached within the recorded run; a round-limit timing is censored and is not used as a successful time-to-target speedup. Timing drivers sharing an output directory use a lock to prevent overlapping computations.

## Direct comparison with Li, Xu and Zhang (2025)

`compare_li_logistic.py` implements the fixed-factor Algorithm 2 (Li-A2) and adaptive-factor Algorithm 1 (Li-A1) of *A Balanced Augmented Lagrangian Method with Correction for Linearly Constrained Optimization*, DOI: 10.1007/s10915-025-02935-9. The updates follow equations (17), (19)--(21) and Algorithms 1/2. Appendix G of the manuscript gives the consensus specialization, Schur inverse, correction, and adaptive factor. The study does not use Algorithm 3, whose printed predictor ordering needs clarification.

Li-A1 and Li-A2 minimize each complete local logistic proximal objective. They use warm-started L-BFGS-B with `gtol=1e-8`, `ftol=0`, `maxiter=200`, and `maxls=50`, matching the R2-PALM/PJADMM local solver. Achieved stationarity, inner iterations, and local gradient evaluations are recorded. The consensus Schur inverse has linear work and storage in the number of blocks. At `eta=0`, both Li variants cache the old Schur residual by its affine recurrence; one new Schur application is then needed per corrected round.

Each Li family screens 35 predefined combinations at each of p = 16 and 32. For indices i = 0,...,6 and j = 0,...,4, r is entry i of seven logarithmically spaced values from 1e-3 to 1, s is entry (i+2*j) mod 7 of seven values from 1e-2 to 1e2, and eta is entry j of [-1,-0.5,0,0.5,1]. Li-A1 additionally uses entry (i+j) mod 4 of gamma = [1,1.3,1.6,1.9]. This is a balanced coverage design with 35 evaluations per family, rather than the full Cartesian grid. It includes each r and s value five times and each eta value seven times. Selection uses a9a alone: the three fastest converged candidates within 3,000 rounds are each validated twice, and the lowest validation median selects the setting. Candidate counts match the preceding MC-LPALM search; tuning CPU time is not equalized. The scalar MC-LPALM setting comes from that preceding 35-candidate screen. The matrix metric uses the same alpha, beta, and shared scalar coefficient without another search.

The selected settings transfer unchanged to phishing, w8a, and ijcnn1 and to the tighter a9a targets. Both MC implementations and both Li algorithms are timed again in this comparison. No wall-clock ratios mix these fresh runs with the earlier R2-PALM/PJADMM batch. Diagnostics are evaluated at primal predictors, using the same reference solutions and zero initialization. Final timings include setup, complete local solves, multiplier prediction, correction, adaptive-factor calculation, and stopping diagnostics. Runs are serial with one BLAS thread and a 20,000-round limit. The three target pairs (objective gap, consensus residual) are (5e-4,1e-4), (1e-5,1e-5), and (1e-6,1e-6).

All records are in `li_direct/`: predefined-screen and validation CSVs, selected settings, raw repeated timings and histories, reference metadata and data checksums, environment metadata, and `PROTOCOL.md`. `make_li_figures.py` rebuilds Table 8 and Figure 9 directly from `final_raw.csv` and `precision_raw.csv`, including unsuccessful runs. A cross or dagger marks a target not reached in every repetition; those timings are censored and excluded from successful time-to-target ratios.

An additional local-tolerance check uses a9a at p=32 and the standard outer targets. Local stationarity tolerances 1e-6 and 1e-8 are compared with unchanged selected algorithm parameters and three fresh runs of all four implementations (24 runs). This check was specified before final timings were produced. MC-LPALM has no inner optimizer, so this tolerance does not alter its gradient predictions. The complete records and summaries are `inner_raw.csv`, `inner_histories.csv`, and `inner_summary.csv` in `li_direct/`.

During the initial precision batch, one p=32 standard-target wall-clock record spanned an overnight computer suspension. The entire affected four-method, three-repetition target group was rerun with frozen settings. `li_direct/precision_raw.csv` contains the completed analysis batch, `li_direct/precision_initial_*.csv` preserves the unmodified initial batch, `li_direct/PRECISION_TIMING_REPAIR.md` records the replacement rule, and `li_precision_repair/` preserves every replacement run. No individual favorable timing was selected.

To rebuild the new table and figure:

```bash
python make_li_figures.py --data-dir . --out-dir ./recomputed
```

To repeat the new experiments, first rerun the preceding MC-LPALM selection, or use the supplied `r2_direct/` archive with the four original LIBSVM data files in `./data`:

```bash
python compare_li_logistic.py --mode tune --data-dir ./data --out-dir ./li_recomputed --mc-archive ./r2_direct --datasets a9a --p-values 16 32
python compare_li_logistic.py --mode final --data-dir ./data --out-dir ./li_recomputed --mc-archive ./r2_direct --repetitions 3
python compare_li_logistic.py --mode precision --data-dir ./data --out-dir ./li_recomputed --mc-archive ./r2_direct --datasets a9a --repetitions 3
python compare_li_logistic.py --mode inner --data-dir ./data --out-dir ./li_recomputed --mc-archive ./r2_direct --datasets a9a --p-values 32 --inner-tolerances 1e-6 1e-8 --repetitions 3
python make_li_figures.py --data-dir ./li_recomputed --out-dir ./recomputed_li
```

The archive preserves every screened candidate and every repeated final run, regardless of the fastest method.
