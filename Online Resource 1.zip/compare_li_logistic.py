"""Li, Xu and Zhang (2025), Algorithms 1/2, on logistic consensus.

Source: equations (17),(19)-(21), Algorithms 1/2 (not ambiguous Algorithm 3).
Eta=0 caches the old Schur residual, including adaptive-factor runs.
Each Li family screens 35 predeclared candidates, validates three twice,
and transfers a9a settings. MC settings are from the preceding 35-candidate
screen; curvature metrics receive no additional search. All diagnostics
are at primal predictors; algorithm setup and inner solves are timed.
"""
from __future__ import annotations
import argparse
import json
import platform
import shutil
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from compare_r2_logistic import load_problem, parts_for, threshold, timing_lock, run
from compare_curvature_metrics import run_curvature
import numpy as np
import pandas as pd
import scipy
from scipy.linalg import eigvalsh
from scipy.optimize import minimize
from threadpoolctl import threadpool_limits

LI_METHODS = ['Li2025-fixed', 'Li2025-adaptive']
METHODS = ['MC-LPALM', 'MC-LPALM-curvature'] + LI_METHODS
R_VALUES = np.geomspace(1e-3, 1.0, 7)
S_VALUES = np.geomspace(1e-2, 1e2, 7)
ETAS = [-1., -.5, 0., .5, 1.]
GAMMAS = [1., 1.3, 1.6, 1.9]

def candidate_grid(method):
    rows = []
    for j, eta in enumerate(ETAS):
        for i, r in enumerate(R_VALUES):
            rows.append(dict(method=method, r=float(r), s=float(S_VALUES[(i+2*j)%7]),
                             eta=eta, gamma=1. if method.endswith('fixed') else GAMMAS[(i+j)%4]))
    return rows

def parameters_match(record, parameters):
    """Match a checkpoint despite harmless decimal CSV roundoff."""
    for key,value in parameters.items():
        if key=='method':
            if record.get(key)!=value:
                return False
        elif not np.isclose(float(record[key]),float(value),rtol=1e-12,atol=1e-15):
            return False
    return True

def run_li(method, parts, full, reg, ref, r, s, eta, gamma=1.,
           gap_tol=5e-4, res_tol=1e-4, maxit=20000, inner_tol=1e-8, workers=1):
    p, d = len(parts), full.x.shape[1]
    start = time.perf_counter()
    u, z, lam = np.zeros((p,d)), np.zeros(d), np.zeros((p,d))
    warm = np.zeros((p,d))
    old = np.zeros((p,d))
    inverse_diagonal = 1. / (s+1./r)
    def schur(v):
        return inverse_diagonal*(v-v.sum(axis=0)/(r*s+p+1))
    def schur_norm(v):
        return (s+1./r)*float(np.square(v).sum())+float(np.square(v.sum(axis=0)).sum())/r
    rho_limit = 2.
    for sigma2 in [1., float(p+1)]:
        sigma = np.sqrt(sigma2)
        ss = s+sigma2/r
        qm = np.array([[r, -eta*sigma],[-sigma, ss]])
        mm = np.array([[1., -eta*sigma/r],[-sigma/ss, 1.]])
        mhm = mm.T@np.diag([r,ss])@mm
        rho_limit = min(rho_limit, float(eigvalsh(qm+qm.T,mhm)[0]))
    executor = ThreadPoolExecutor(max_workers=workers) if workers>1 else None
    setup = time.perf_counter()-start
    local_seconds = correction_seconds = diagnostics_seconds = prediction_dual_seconds = 0.
    gradients = inner_iterations = failures = system_solves = 0
    max_stationarity = 0.
    rho_min, rho_max = np.inf, 0.
    history = []
    status, gap, residual = 'maxit', np.inf, np.inf
    for k in range(1,maxit+1):
        tick = time.perf_counter()
        if eta != 0:
            old = schur(u-z)
            system_solves += 1
        shifted = lam-(1.+eta)*old
        prediction_dual_seconds += time.perf_counter()-tick
        def predict(i):
            center = u[i]+shifted[i]/r
            def objective(v):
                value, grad = parts[i].value_grad(v)
                delta = v-center
                return value+.5*r*float(delta@delta), grad+r*delta
            sol = minimize(objective, warm[i], jac=True, method='L-BFGS-B',
                           options={'maxiter':200,'ftol':0.,'gtol':inner_tol,'maxls':50})
            return sol.x, int(sol.nfev), int(sol.nit), float(np.max(np.abs(sol.jac)))
        tick = time.perf_counter()
        predictions = list(executor.map(predict,range(p))) if executor else [predict(i) for i in range(p)]
        ut = np.vstack([item[0] for item in predictions])
        zt = threshold(z-shifted.sum(axis=0)/r,reg/r)
        warm = ut.copy()
        gradients += sum(item[1] for item in predictions)
        inner_iterations += sum(item[2] for item in predictions)
        stationarity = max(item[3] for item in predictions)
        max_stationarity = max(max_stationarity, stationarity)
        failed = sum(item[3]>10*inner_tol for item in predictions)
        failures += failed
        local_seconds += time.perf_counter()-tick
        if failed:
            status = 'inner_failure'
            break
        if k==1 or k%5==0 or k==maxit:
            tick = time.perf_counter()
            value = full.value_grad(zt)[0]+reg*np.abs(zt).sum()
            gap = max(float(value-ref),0.)
            residual = float(np.linalg.norm(ut-zt,axis=1).max())
            diagnostics_seconds += time.perf_counter()-tick
            history.append(dict(round=k,seconds=time.perf_counter()-start,
                                objective_gap=gap,consensus_residual=residual))
            if gap<=gap_tol and residual<=res_tol:
                status = 'converged'
                break
        if k==maxit:
            break
        tick = time.perf_counter()
        du, dz = u-ut, z-zt
        cu, cz = du-eta*old/r, dz+eta*old.sum(axis=0)/r
        q = schur(ut-zt)
        system_solves += 1
        if method.endswith('adaptive'):
            cross = float(np.sum((du-dz)*old))
            numerator = r*(float(np.square(du).sum())+float(dz@dz))-(eta+1)*cross+schur_norm(old)
            denominator = r*(float(np.square(cu).sum())+float(cz@cz))+schur_norm(q)
            if denominator<=0 or numerator<=0 or not np.isfinite(denominator+numerator):
                status = 'invalid_correction'
                break
            rho = gamma*numerator/denominator
        else:
            rho = 1.
        rho_min, rho_max = min(rho_min,rho), max(rho_max,rho)
        u -= rho*cu
        z -= rho*cz
        lam -= rho*q
        if eta==0:
            old = (1-rho)*old+rho*q
        correction_seconds += time.perf_counter()-tick
    if executor:
        executor.shutdown()
    row = dict(method=method,r=r,s=s,eta=eta,gamma=gamma,alpha=np.nan,beta=np.nan,
               workers=workers,inner_tolerance=inner_tol,rounds=k,seconds=time.perf_counter()-start,
               setup_seconds=setup,local_seconds=local_seconds,correction_seconds=correction_seconds,
               diagnostics_seconds=diagnostics_seconds,prediction_dual_seconds=prediction_dual_seconds,
               local_gradient_evaluations=gradients,inner_iterations=inner_iterations,
               max_inner_stationarity=max_stationarity,failed_inner_solves=failures,
               objective_gap=gap,consensus_residual=residual,status=status,
               gap_tolerance=gap_tol,residual_tolerance=res_tol,schur_solves=system_solves,
               correction_factor_min=rho_min,correction_factor_max=rho_max,
               nonergodic_factor_limit=rho_limit,
               nonergodic_matrix_condition=bool(rho_max<rho_limit),cached_old_residual=bool(eta==0))
    return row, history

def save_rows(path,rows):
    pd.DataFrame(rows).to_csv(path,index=False)

def summary(path,rows):
    frame = pd.DataFrame(rows)
    keys = ['dataset','p','method','gap_tolerance','residual_tolerance','workers','inner_tolerance']
    frame.groupby(keys,as_index=False).agg(
        repetitions=('seconds','size'),median_seconds=('seconds','median'),
        q1_seconds=('seconds',lambda x:x.quantile(.25)),q3_seconds=('seconds',lambda x:x.quantile(.75)),
        median_rounds=('rounds','median'),median_gradients=('local_gradient_evaluations','median'),
        median_inner_iterations=('inner_iterations','median'),median_setup_seconds=('setup_seconds','median'),
        median_local_seconds=('local_seconds','median'),median_correction_seconds=('correction_seconds','median'),
        max_gap=('objective_gap','max'),max_residual=('consensus_residual','max'),
        max_inner_stationarity=('max_inner_stationarity','max'),inner_failures=('failed_inner_solves','sum'),
        all_converged=('status',lambda x:bool((x=='converged').all()))
    ).to_csv(path,index=False)

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--mode',choices=['tune','final','precision','inner'],required=True)
    parser.add_argument('--data-dir',type=Path,required=True)
    parser.add_argument('--out-dir',type=Path,required=True)
    parser.add_argument('--mc-archive',type=Path,required=True)
    parser.add_argument('--datasets',nargs='+',default=['a9a','phishing','w8a','ijcnn1'])
    parser.add_argument('--p-values',nargs='+',type=int,default=[16,32])
    parser.add_argument('--repetitions',type=int,default=3)
    parser.add_argument('--inner-tolerances',nargs='+',type=float,default=[1e-6,1e-8])
    args = parser.parse_args()
    out = args.out_dir.resolve()
    out.mkdir(parents=True,exist_ok=True)
    for name in ['a9a','phishing','w8a','ijcnn1']:
        target = out/f'reference_{name}.json'
        if not target.exists():
            shutil.copy2(args.mc_archive/f'reference_{name}.json',target)
    env = dict(python=platform.python_version(),numpy=np.__version__,scipy=scipy.__version__,
               blas_threads=1,platform=platform.platform(),r_values=R_VALUES.tolist(),s_values=S_VALUES.tolist(),
               etas=ETAS,gammas=GAMMAS,screen_budget_per_family_per_p=35,
               grid='r index i; s index (i+2*j)%7; eta index j; adaptive gamma index (i+j)%4',
               selection='three fastest converged screens; two validations; minimum validation median',
               screen_maxit=3000,final_maxit=20000,inner_solver='warm-started L-BFGS-B',
               standard_inner_gtol=1e-8,supplementary_inner_gtols=args.inner_tolerances,
               inner_maxiter=200,inner_ftol=0.,inner_maxls=50,
               stopping_iterate='primal predictor',stopping_frequency=5,
               timing_scope='setup, local solves, dual prediction, correction and diagnostics',
               li_source='doi:10.1007/s10915-025-02935-9; Algorithms 1/2, eqs.17,19-21',
               cache='eta=0 old residual reused via affine recurrence; no dense pd-by-pd matrices')
    (out/'environment_li.json').write_text(json.dumps(env,indent=2))
    rows, histories = [], []
    with threadpool_limits(limits=1):
        for dataset in args.datasets:
            x,y,full,reg,ref = load_problem(dataset,args.data_dir,out)
            for p in args.p_values:
                parts = parts_for(x,y,p)
                if args.mode=='tune':
                    path = out/f'tune_screen_{dataset}_p{p}.csv'
                    screen = pd.read_csv(path).to_dict('records') if path.exists() else []
                    grid = [row for method in LI_METHODS for row in candidate_grid(method)]
                    np.random.default_rng(20260928+p).shuffle(grid)
                    for candidate in grid:
                        if any(parameters_match(old,candidate) for old in screen):
                            continue
                        row,_ = run_li(parts=parts,full=full,reg=reg,ref=ref,maxit=3000,**candidate)
                        row.update(dataset=dataset,p=p,phase='screen')
                        screen.append(row)
                        save_rows(path,screen)
                        print('SCREEN',p,candidate,round(row['seconds'],3),row['rounds'],row['status'],flush=True)
                    valpath = out/f'validation_{dataset}_p{p}.csv'
                    validation = pd.read_csv(valpath).to_dict('records') if valpath.exists() else []
                    frame = pd.DataFrame(screen)
                    for rep in range(1,3):
                        for method in LI_METHODS[::1 if rep==1 else -1]:
                            top = frame[(frame.method==method)&(frame.status=='converged')].nsmallest(3,'seconds')
                            if len(top)<3:
                                raise RuntimeError(f'Fewer than three converged candidates: {p} {method}')
                            for _,candidate in top.iterrows():
                                params = {key:candidate[key] for key in ['method','r','s','eta','gamma']}
                                if any(old.get('repetition')==rep and parameters_match(old,params) for old in validation):
                                    continue
                                row,_ = run_li(parts=parts,full=full,reg=reg,ref=ref,**params)
                                row.update(dataset=dataset,p=p,phase='validation',repetition=rep)
                                validation.append(row)
                                save_rows(valpath,validation)
                                print('VALIDATE',p,params,rep,round(row['seconds'],3),row['status'],flush=True)
                    val = pd.DataFrame(validation)
                    med = val.groupby(['method','r','s','eta','gamma'],as_index=False).agg(
                        seconds=('seconds','median'),all_converged=('status',lambda x:bool((x=='converged').all())))
                    chosen = med[med.all_converged].sort_values('seconds').groupby('method',sort=False).head(1)
                    chosen.to_csv(out/f'selected_a9a_p{p}.csv',index=False)
                    print('SELECTED',p,chosen.to_dict('records'),flush=True)
                    continue
                chosen = pd.read_csv(out/f'selected_a9a_p{p}.csv').set_index('method')
                mc = pd.read_csv(args.mc_archive/f'selected_a9a_p{p}.csv').set_index('method').loc['MC-LPALM']
                targets = [(5e-4,1e-4)] if args.mode in ['final','inner'] else [(5e-4,1e-4),(1e-5,1e-5),(1e-6,1e-6)]
                tolerances = args.inner_tolerances if args.mode=='inner' else [1e-8]
                for gt,rt,it in [(gt,rt,it) for gt,rt in targets for it in tolerances]:
                    for rep in range(1,args.repetitions+1):
                        shift = (rep+p)%len(METHODS)
                        order = METHODS[shift:]+METHODS[:shift]
                        for method in order:
                            if method in LI_METHODS:
                                params = chosen.loc[method]
                                row,trace = run_li(method,parts,full,reg,ref,params.r,params.s,params.eta,params.gamma,gt,rt,inner_tol=it)
                            elif method=='MC-LPALM':
                                row,trace = run(method,parts,full,reg,ref,mc.alpha,mc.beta,gt,rt,inner_tol=it)
                            else:
                                row,trace = run_curvature(parts,full,reg,ref,mc.alpha,mc.beta,gt,rt,inner_tol=it)
                            row.update(dataset=dataset,p=p,repetition=rep,selection_dataset='a9a')
                            rows.append(row)
                            save_rows(out/f'{args.mode}_raw.csv',rows)
                            for point in trace:
                                point.update(dataset=dataset,p=p,method=method,repetition=rep,gap_tolerance=gt,residual_tolerance=rt,inner_tolerance=it)
                            histories.extend(trace)
                            save_rows(out/f'{args.mode}_histories.csv',histories)
                            print('RUN',args.mode,dataset,p,method,gt,it,rep,round(row['seconds'],3),row['rounds'],row['status'],flush=True)
    if rows:
        summary(out/f'{args.mode}_summary.csv',rows)
    print('STAGE_COMPLETE',args.mode,flush=True)

if __name__=='__main__':
    pre = argparse.ArgumentParser(add_help=False)
    pre.add_argument('--out-dir',type=Path,required=True)
    parsed,_ = pre.parse_known_args()
    with timing_lock(parsed.out_dir.resolve()):
        main()
